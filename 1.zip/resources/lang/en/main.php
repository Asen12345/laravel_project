<?php

return [
	'welcome' => 'Welcome',
];
