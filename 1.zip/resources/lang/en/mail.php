<?php

return [
	'verify_subject' => 'Verify Email Address',
	'verify_text_line_1' => 'Please click the button below to verify your email address',
	'verify_button' => 'Verify Email Address',
	'verify_text_line_2' => 'If you did not create an account, no further action is required',
];
