<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use App\Models\Setting;
use App\Models\InvestorPayment;
use App\Models\User;

class InvestorController extends Controller
{
	public function withdraw_modal()
	{
		$investor_fee = Setting::where('key', 'investor_fee')->pluck('value')->first();
		return view('investor.modals.withdraw', compact(['investor_fee']));
	}


	public function index()
	{
		$payments = auth()->user()->investor_payments;
		return view('investor.finances', compact(['payments']));
	}

	public function withdraw(Request $request)
	{
		$validator = Validator::make($request->all(), [
			'amount' => ['required', 'integer'],
			'wallet' => ['required'],
		]);

		if ($validator->fails()) {
			return response()->json(['errors' => $validator->errors()]);
		}

		$userId = auth()->user()->id;
		$req = InvestorPayment::where('user_id', $userId)
			->where('type', 2)
			->where('status', 0)
			->count();

		if ($req) {
			return response()->json(['errors' => [
				'other' => [
					__("Wait, please! You already have pending withdrawal requests")
				]
			]]);
		}

		if (auth()->user()->balance() < $request->get('amount')) {
			return response()->json(['errors' => [
				'other' => [
					__("Insufficient funds on the user's balance")
				]
			]]);
		}

		if (empty(auth()->user()->phone)) {
			return response()->json(['errors' => [
				'other' => [
					__("Confirm your phone number please")
				]
			]]);
		}

		$code = auth()->user()->generate_code();

		if ($code) {
			$request->session()->put('code', $code);
			$request->session()->put('amount', $request->get('amount'));
			$request->session()->put('wallet', $request->get('wallet'));

			return response()->json(['success' => true]);
		} else {
			return response()->json(['errors' => [
				'other' => [
					__("You can request a second code in a minute")
				]
			]]);
		}
	}


	public function withdraw_go(Request $request)
	{

		$user = auth()->user();
		$userId = $user->id;

		$code = $user->phone_code;
		$validator = Validator::make($request->all(), [
			'code' => ["required", "code_correct", "code_live", "code_count"], //  new PhoneCodeCount , new PhoneCodeCorrect, new PhoneCodeLive  
		]);

		if ($validator->fails()) {
			return response()->json(['errors' => $validator->errors()]);
		}

		User::whereId($userId)->update([
			'phone_code_error' => NULL,
			'phone_code' => NULL,
			'phone_code_at' => NULL,
		]);

		$investor_fee = Setting::where('key', 'investor_fee')->pluck('value')->first();
		$fee = $request->session()->get('amount') * $investor_fee / 100;

		$payment = InvestorPayment::create([
			'user_id' => $userId,
			'created_at' => date('Y-m-d H:i:s'),
			'type' => 2,
			'status' => 0,
			'amount' => $request->session()->get('amount'),
			'fee' => $fee,
			'payment_system' => 0,
			'payer' => '',
			'payee' => '',
			'batcn' => '',
			'confirm_date' => NULL
		]);

		User::whereId($userId)->update(['purse' => $request->session()->get('wallet')]);

		if ($payment) {
			return response()->json(['success' => true]);
		} else {
			return response()->json(['errors' => [
				'other' => [
					__("Sorry, an unknown error has occurred. Repeat the operation")
				]
			]]);
		}
	}
}
