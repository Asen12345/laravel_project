<?php $__env->startSection('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Robots'), false); ?></h1>

	<a class="btn btn-danger" href="<?php echo e(route('admin.robots.create'), false); ?>">
		<?php echo e(__('Create robot'), false); ?>

	</a>
</div>

<!-- Row -->
<div class="row">
	<!-- DataTable -->
	<div class="col-lg-12">
		<div class="card mb-4">

			<div class="card-header py-3 d-flex flex-row align-items-center justify-content-end">

			</div>
			<!-- </div> -->


			<div class="table-responsive p-3">
				<table class="table align-items-center table-flush table-hover" id="robots">
					<thead class="thead-light">
						<tr>
							<th><?php echo e(__('Date'), false); ?></th>
							<th><?php echo e(__('Title'), false); ?></th>
							<th><?php echo e(__('Version'), false); ?></th>
							<th><?php echo e(__('Cover'), false); ?></th>
							<th><?php echo e(__('Published'), false); ?></th>
							<th><?php echo e(__('Language'), false); ?></th>
							<th></th>
						</tr>
					</thead>
					<tbody>

						<?php $__empty_1 = true; $__currentLoopData = $robots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $robot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td>
								<?php if($robot->created_at): ?>
								<?php echo e(date('d.m.Y H:i', strtotime($robot->created_at)), false); ?>

								<?php else: ?>
								–
								<?php endif; ?>
							</td>
							<td>
								<?php echo e($robot->title, false); ?>

							</td>
							<td>
								<?php echo e($robot->version, false); ?>

							</td>
							<td>
								<?php if($robot->getFirstMediaUrl('images', 'thumb')): ?>
								<img width="60" height="60" src="<?php echo e($robot->getFirstMediaUrl('images', 'thumb'), false); ?>">
								<?php endif; ?>
							</td>
							<td>
								<?php if($robot->public): ?>
								<span class="badge badge-success"><?php echo e(__('Published'), false); ?></span>
								<?php else: ?>
								<span class="badge badge-danger"><?php echo e(__('Draft'), false); ?></span>
								<?php endif; ?>
							</td>
							<td>

								<?php if($robot->lang == 'en'): ?>
								<span class="badge badge-dark"><?php echo e(__('English'), false); ?></span>
								<?php endif; ?>
								<?php if($robot->lang == 'ru'): ?>
								<span class="badge badge-light"><?php echo e(__('Russian'), false); ?></span>
								<?php endif; ?>

							</td>
							<td>
								<a class="btn btn-primary mr-2" href="<?php echo e(route('admin.robot-settings.index', $robot->id), false); ?>"><i class="fas fa-cogs""></i></a>
								<a class=" btn btn-primary mr-2" href="<?php echo e(route('admin.robots.edit', $robot->id), false); ?>"><i class="far fa-edit"></i></a>

								<form onsubmit="return confirm('<?php echo e(__('Are you sure you want to delete this entry?'), false); ?>')" style="display: inline-block;" method="POST" action="<?php echo e(route('admin.robots.destroy', $robot->id), false); ?>">
									<?php echo csrf_field(); ?>
									<?php echo method_field('DELETE'); ?>
									<button class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
								</form>

							</td>

						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<?php endif; ?>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<!--Row-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('theme/vendor/datatables/jquery.dataTables.min.js'), false); ?>"></script>
<script src="<?php echo e(asset('theme/vendor/datatables/dataTables.bootstrap4.min.js'), false); ?>"></script>

<?php if(app()->getLocale() == 'ru'): ?>
<?php ($locale = "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Russian.json"); ?>
<?php else: ?>
<?php ($locale = "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/English.json"); ?>
<?php endif; ?>

<!-- Page level custom scripts -->
<script>
	$(document).ready(function() {

		// Таблица
		$('#robots').DataTable({
			"language": {
				"url": "<?php echo e($locale, false); ?>"
			},
			"order": false
		});

	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/admin/robots/index.blade.php ENDPATH**/ ?>