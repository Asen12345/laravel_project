[<?php echo e($slot, false); ?>](<?php echo e($url, false); ?>)
<?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>