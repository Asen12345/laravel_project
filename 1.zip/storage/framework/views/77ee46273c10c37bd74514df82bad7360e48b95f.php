<?php $__env->startSection('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Edit user info'), false); ?></h1>

	<a class="btn btn-light" href="<?php echo e(route('admin.users'), false); ?>">
		<?php echo e(__('Back'), false); ?>

	</a>
</div>

<!-- Row -->
<div class="row">

	<div class="col-md-6">
		<div class="card mb-4">

			<div class="card-body">

				<?php if(session('personal_data_success')): ?>
				<div class="alert alert-success" role="alert">
					<?php echo e(session('personal_data_success'), false); ?>

				</div>
				<?php endif; ?>


				<form class="user" method="POST" action="<?php echo e(route('admin.users.personal_data', $user), false); ?>">
					<?php echo csrf_field(); ?>

					<div class="my-3 row">
						<div class="col-md-6"><?php echo e(__('Firstname'), false); ?></div>
						<div class="col-md-6">

							<input type="text" class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="first_name" value="<?php echo e($user->first_name, false); ?>">

							<?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message, false); ?></strong>
							</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

						</div>
					</div>
					<div class="my-3 row">
						<div class="col-md-6"><?php echo e(__('Lastname'), false); ?></div>
						<div class="col-md-6">
							<input type="text" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="last_name" value="<?php echo e($user->last_name, false); ?>">

							<?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message, false); ?></strong>
							</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
					</div>
					<div class="my-3 row">
						<div class="col-md-6"><?php echo e(__('E-mail'), false); ?></div>
						<div class="col-md-6">
							<input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e($user->email, false); ?>">

							<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message, false); ?></strong>
							</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
					</div>
					<div class="my-3 row">
						<div class="col-md-6"><?php echo e(__('Phone'), false); ?></div>
						<div class="col-md-6">
							<input type="text" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone" value="<?php echo e($user->phone, false); ?>">

							<?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message, false); ?></strong>
							</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
					</div>

					<?php if($user->curator): ?>
					<div class="my-3 row">
						<div class="col-md-6"><?php echo e(__('Curator'), false); ?></div>
						<div class="col-md-6"><a href="<?php echo e(route('admin.users.info', $user->curator->id), false); ?>"><?php echo e($user->curator->first_name, false); ?> <?php echo e($user->curator->last_name, false); ?></a></div>
					</div>
					<?php endif; ?>

					<div class="my-3 row">
						<div class="col-md-6"></div>
						<div class="col-md-6">
							<button type="submit" class="btn btn-primary">
								<?php echo e(__('Save'), false); ?>

							</button>
						</div>
					</div>

				</form>

				<form class="float-left mr-1" method="POST" action="<?php echo e(route('admin.users.login_as'), false); ?>">
					<?php echo csrf_field(); ?>
					<input type="hidden" name="user_id" value="<?php echo e($user->id, false); ?>">
					<button type="submit" class="btn btn-success">
						<?php echo e(__('Login as user'), false); ?>

					</button>
				</form>

			</div>

		</div>
	</div>



	<div class="col-md-6">
		<div class="card mb-4">
			<div class="card-header">
				<h6 class="m-0 font-weight-bold text-primary pt-3"><?php echo e(__('Change password'), false); ?></h6>
			</div>

			<div class="card-body">

				<?php if(session('change_password_success')): ?>
				<div class="alert alert-success" role="alert">
					<?php echo e(session('change_password_success'), false); ?>

				</div>
				<?php endif; ?>

				<form class="user" method="POST" action="<?php echo e(route('admin.users.change_password', $user), false); ?>">
					<?php echo csrf_field(); ?>

					<div class="form-group">
						<label for="new_password"><?php echo e(__('New Password'), false); ?></label>

						<input id="new_password" type="password" class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="new_password">

						<?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message, false); ?></strong>
						</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>

					<div class="form-group">
						<label for="new_password_confirmation"><?php echo e(__('Confirm Password'), false); ?></label>

						<input id="new_password_confirmation" type="password" class="form-control <?php $__errorArgs = ['new_password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="new_password_confirmation">

						<?php $__errorArgs = ['new_password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message, false); ?></strong>
						</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>


					<div class="form-group">
						<button type="submit" class="btn btn-primary">
							<?php echo e(__('Change password'), false); ?>

						</button>
					</div>
				</form>


			</div>
		</div>
	</div>

</div>

<div class="row">

	<div class="col-md-12">
		<div class="card mb-4">
			<div class="card-header">
				<h3><?php echo e(__('Licenses'), false); ?></h3>
			</div>
			<div class="card-body">

				<!-- ключ, дата активации, номер счета (accounts->number). При нажатии на номер счета должна выводиться полная информация по счету из базы. Во всплывающем окне должно быть несколько кнопок: блокироват, отвязать от счет, продлить доступ. -->

				<div class="table-responsive">
					<table class="table align-items-center table-flush table-hover" id="licenses">
						<thead class="thead-light">
							<tr>
								<th><?php echo e(__('Activation key'), false); ?></th>
								<th><?php echo e(__('Date activation'), false); ?></th>
								<th><?php echo e(__('Check number'), false); ?></th>
								<th><?php echo e(__('Check type'), false); ?></th>
								<th></th>
							</tr>
						</thead>
						<tbody>


							<?php $__empty_1 = true; $__currentLoopData = $user->accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td><?php echo e($account->active_kod, false); ?></td>
								<td>
									<?php if($account->date_activation): ?>
									<?php echo e(date('d.m.Y H:i', strtotime($account->date_activation)), false); ?>

									<?php else: ?>
									–
									<?php endif; ?></td>
								<td>
									<?php if($account->number): ?>
									<?php echo e($account->number, false); ?>

									<?php else: ?>
									<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#window-account-number" num="<?php echo e($account->id, false); ?>" id="#modalCenter">
										<?php echo e(__('To appoint'), false); ?>

									</button>
									<?php endif; ?>
								</td>
								<td>
									<?php if($account->real): ?>
									<span class="badge badge-success"><?php echo e(__('Real'), false); ?></span>
									<?php else: ?>
									<?php if($account->real === NULL): ?>
									–
									<?php else: ?>
									<span class="badge badge-danger"><?php echo e(__('Demo'), false); ?></span>
									<?php endif; ?>
									<?php endif; ?>
								</td>
								<td>
									<?php if($account->number): ?>
									<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#window-detail<?php echo e($account->id, false); ?>" id="#modalCenter">
										<?php echo e(__('Detail'), false); ?>

									</button>
									<?php endif; ?>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<?php endif; ?>

						</tbody>
					</table>
				</div>


			</div>

		</div>
	</div>
</div>
<!--Row-->



<div class="modal fade" id="window-account-number" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('To appoint account number'), false); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">

				<form class="to-appoint" method="post" action="<?php echo e(route('to_appoint'), false); ?>">
					<?php echo csrf_field(); ?>

					<input id="account_id" name="id" value="0" type="hidden">

					<div class="form-group">
						<label for="email"><?php echo e(__('Account number'), false); ?></label>

						<input id="account_number" type="text" class="form-control account_number_input_error" name="number" value="">

						<span class="invalid-feedback account_number_error" role="alert">
							<strong></strong>
						</span>

					</div>

					<div class="form-group">
						<button class="btn btn-success"><?php echo e(__('To appoint'), false); ?></button>
					</div>

				</form>



			</div>
		</div>
	</div>
</div>


<?php $__empty_1 = true; $__currentLoopData = $user->accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<!-- Modal Center -->
<div class="modal fade" id="window-detail<?php echo e($account->id, false); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('License details'), false); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Activation key'), false); ?></div>
					<div class="col-md-6 text-right"><?php echo e($account->active_kod, false); ?></div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Robot'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php if($account->project): ?>
						<?php echo e($account->project->name, false); ?>

						<?php else: ?>
						<?php echo e($account->project_id, false); ?>

						<?php endif; ?>
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Robot version'), false); ?></div>
					<div class="col-md-6 text-right"><?php echo e($account->ver, false); ?></div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Date activation'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php if($account->date_activation): ?>
						<?php echo e(date('d.m.Y H:i', strtotime($account->date_activation)), false); ?>

						<?php else: ?>
						–
						<?php endif; ?>
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Date end of license'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php if($account->date_expiration): ?>
						<?php echo e(date('d.m.Y H:i', strtotime($account->date_expiration)), false); ?>

						<?php else: ?>
						–
						<?php endif; ?>
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Check number'), false); ?></div>
					<div class="col-md-6 text-right"><?php echo e($account->number, false); ?></div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Shoulder'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php if($account->leverage): ?>
						1:<?php echo e($account->leverage, false); ?>

						<?php else: ?>
						–
						<?php endif; ?>
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Check type'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php if($account->real): ?>
						<span class="badge badge-success"><?php echo e(__('Real'), false); ?></span>
						<?php else: ?>
						<?php if($account->real === NULL): ?>
						–
						<?php else: ?>
						<span class="badge badge-danger"><?php echo e(__('Demo'), false); ?></span>
						<?php endif; ?>
						<?php endif; ?>
					</div>
				</div>

				<div class="mt-5 mb-3">

					<form class="block-account float-left mr-1" method="POST" action="<?php echo e(route('admin.users.licenses.block'), false); ?>">
						<?php echo csrf_field(); ?>
						<input type="hidden" name="account_id" value="<?php echo e($account->id, false); ?>">

						<button type="submit" class="btn btn-primary unblock-button" <?php if(!$account->blocked): ?> hidden <?php endif; ?> >
							<?php echo e(__('Unblock'), false); ?>

						</button>
						<button type="submit" class="btn btn-danger block-button" <?php if($account->blocked): ?> hidden <?php endif; ?> >
							<?php echo e(__('Block'), false); ?>

						</button>
					</form>


					<?php if($account->number): ?>
					<form class="detach-account float-left mr-1" method="POST" action="<?php echo e(route('admin.users.licenses.detach'), false); ?>">
						<?php echo csrf_field(); ?>
						<input type="hidden" name="account_id" value="<?php echo e($account->id, false); ?>">

						<button type="submit" class="btn btn-danger">
							<?php echo e(__('Detach from account'), false); ?>

						</button>
					</form>
					<?php endif; ?>


					<form class="renew-account float-left mr-1" method="POST" action="<?php echo e(route('admin.users.licenses.renew'), false); ?>">
						<?php echo csrf_field(); ?>
						<input type="hidden" name="account_id" value="<?php echo e($account->id, false); ?>">

						<button type="submit" class="btn btn-success">
							<?php echo e(__('Renew access'), false); ?>

						</button>
					</form>



				</div>

			</div>
		</div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<?php endif; ?>

<style>
	.custom-file-label::after {
		content: "<?php echo e(__('Browse'), false); ?>"
	}
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('theme/vendor/datatables/jquery.dataTables.min.js'), false); ?>"></script>
<script src="<?php echo e(asset('theme/vendor/datatables/dataTables.bootstrap4.min.js'), false); ?>"></script>

<?php if(app()->getLocale() == 'ru'): ?>
<?php ($locale = "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Russian.json"); ?>
<?php else: ?>
<?php ($locale = "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/English.json"); ?>
<?php endif; ?>

<script>
	$(document).ready(function() {

		$('#licenses').DataTable({
			"language": {
				"url": "<?php echo e($locale, false); ?>"
			},
			"order": false
		});

		$('#window-account-number').on('show.bs.modal', function(e) {
			$('#account_id').val($(e.relatedTarget).attr('num'));
		});


		$("body").on('submit', '.to-appoint', function(e) {
			e.preventDefault();
			var form = $(this);
			$.ajax({
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: form.serialize(),
				success: function(data) {
					if (data.error) {
						$('.account_number_error strong').html(data.error[0]);
						$('.account_number_error').show();
						$('.account_number_input_error').addClass('is-invalid');
					} else {
						location.reload();
					}
					console.log(data);
				}
			});
		});

		$("body").on('submit', '.block-account', function(e) {
			e.preventDefault();
			var form = $(this);
			$.ajax({
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: form.serialize(),
				success: function(data) {
					if (data.success) {
						if (data.value) {
							$('.unblock-button').removeAttr('hidden');
							$('.block-button').attr('hidden', 'hidden');
						} else {
							$('.block-button').removeAttr('hidden');
							$('.unblock-button').attr('hidden', 'hidden');
						}
					}
					console.log(data);
				}
			});
		});

		$("body").on('submit', '.detach-account', function(e) {
			e.preventDefault();
			var form = $(this);
			$.ajax({
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: form.serialize(),
				success: function(data) {
					location.reload();
				}
			});
		});

		$("body").on('submit', '.renew-account', function(e) {
			e.preventDefault();
			var form = $(this);
			$.ajax({
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: form.serialize(),
				success: function(data) {
					location.reload();
				}
			});
		});



	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/admin/users/info.blade.php ENDPATH**/ ?>