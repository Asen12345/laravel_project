<?php $__env->startSection('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Licenses'), false); ?></h1>

</div>

<!-- Row -->
<div class="row">
	<!-- DataTable -->
	<div class="col-lg-12">
		<div class="card mb-4">
			<!-- <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"> -->
			<!-- <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Licenses'), false); ?></h6> -->
			<!-- </div> -->
			<div class="table-responsive p-3">
				<table class="table align-items-center table-flush table-hover" id="licenses">
					<thead class="thead-light">
						<tr>
							<th><?php echo e(__('Activation key'), false); ?></th>
							<th><?php echo e(__('Date activation'), false); ?></th>
							<th><?php echo e(__('Check number'), false); ?></th>
							<th><?php echo e(__('Check type'), false); ?></th>
							<th></th>
						</tr>
					</thead>
					<!-- <tfoot>
						<tr>
							<th><?php echo e(__('Activation key'), false); ?></th>
							<th><?php echo e(__('Date activation'), false); ?></th>
							<th><?php echo e(__('Check number'), false); ?></th>
							<th><?php echo e(__('Check type'), false); ?></th>
							<th></th>
						</tr>
					</tfoot> -->
					<tbody>



						<?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><?php echo e($account->active_kod, false); ?></td>
							<td>
								<?php if($account->date_activation AND $account->date_activation != '0000-00-00 00:00:00' AND $account->date_activation != NULL): ?>
								<?php echo e(date('d.m.Y H:i', strtotime($account->date_activation)), false); ?>

								<?php else: ?>
								–
								<?php endif; ?></td>
							<td>
								<?php if($account->number): ?>
								<?php echo e($account->number, false); ?>

								<?php else: ?>
								<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#window-account-number" num="<?php echo e($account->id, false); ?>" id="#modalCenter">
									<?php echo e(__('To appoint'), false); ?>

								</button>
								<?php endif; ?>
							</td>
							<td>
								<?php if($account->real): ?>
								<span class="badge badge-success"><?php echo e(__('Real'), false); ?></span>
								<?php else: ?>
								<?php if($account->real === NULL): ?>
								–
								<?php else: ?>
								<span class="badge badge-danger"><?php echo e(__('Demo'), false); ?></span>
								<?php endif; ?>
								<?php endif; ?>
							</td>
							<td>
								<?php if($account->number): ?>
								<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#window-detail<?php echo e($account->id, false); ?>" id="#modalCenter">
									<?php echo e(__('Detail'), false); ?>

								</button>
								<?php endif; ?>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<?php endif; ?>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<!--Row-->

<div class="modal fade" id="window-account-number" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('To appoint account number'), false); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">

				<form class="user">
					<?php echo csrf_field(); ?>

					<input id="account_id" name="id" value="0" type="hidden">

					<div class="form-group">
						<label for="email"><?php echo e(__('Account number'), false); ?></label>

						<input id="account_number" type="text" class="form-control account_number_input_error" name="number" value="">

						<span class="invalid-feedback account_number_error" role="alert">
							<strong></strong>
						</span>

					</div>

				</form>

				<div class="form-group">
					<button class="btn btn-success to-appoint"><?php echo e(__('To appoint'), false); ?></button>
				</div>

			</div>
		</div>
	</div>
</div>


<?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<!-- Modal Center -->
<div class="modal fade" id="window-detail<?php echo e($account->id, false); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('License details'), false); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Activation key'), false); ?></div>
					<div class="col-md-6 text-right"><?php echo e($account->active_kod, false); ?></div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Robot'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php if($account->project): ?>
						<?php echo e($account->project->name, false); ?>

						<?php else: ?>
						<?php echo e($account->project_id, false); ?>

						<?php endif; ?>
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Robot version'), false); ?></div>
					<div class="col-md-6 text-right"><?php echo e($account->ver, false); ?></div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Date activation'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php if($account->date_activation): ?>
						<?php echo e(date('d.m.Y H:i', strtotime($account->date_activation)), false); ?>

						<?php else: ?>
						–
						<?php endif; ?>
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Date end of license'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php if($account->date_expiration): ?>
						<?php echo e(date('d.m.Y H:i', strtotime($account->date_expiration)), false); ?>

						<?php else: ?>
						–
						<?php endif; ?>
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Check number'), false); ?></div>
					<div class="col-md-6 text-right"><?php echo e($account->number, false); ?></div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Shoulder'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php if($account->leverage): ?>
						1:<?php echo e($account->leverage, false); ?>

						<?php else: ?>
						–
						<?php endif; ?>
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Check type'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php if($account->real): ?>
						<span class="badge badge-success"><?php echo e(__('Real'), false); ?></span>
						<?php else: ?>
						<?php if($account->real === NULL): ?>
						–
						<?php else: ?>
						<span class="badge badge-danger"><?php echo e(__('Demo'), false); ?></span>
						<?php endif; ?>
						<?php endif; ?>
					</div>
				</div>


				<div class="mt-5 mb-3">

					<form class="block-account float-left mr-1" method="POST" action="<?php echo e(route('admin.users.licenses.block'), false); ?>">
						<?php echo csrf_field(); ?>
						<input type="hidden" name="account_id" value="<?php echo e($account->id, false); ?>">

						<button type="submit" class="btn btn-primary unblock-button" <?php if(!$account->blocked): ?> hidden <?php endif; ?> >
							<?php echo e(__('Unblock'), false); ?>

						</button>
						<button type="submit" class="btn btn-danger block-button" <?php if($account->blocked): ?> hidden <?php endif; ?> >
							<?php echo e(__('Block'), false); ?>

						</button>
					</form>


					<?php if($account->number): ?>
					<form class="detach-account float-left mr-1" method="POST" action="<?php echo e(route('admin.users.licenses.detach'), false); ?>">
						<?php echo csrf_field(); ?>
						<input type="hidden" name="account_id" value="<?php echo e($account->id, false); ?>">

						<button type="submit" class="btn btn-danger">
							<?php echo e(__('Detach from account'), false); ?>

						</button>
					</form>
					<?php endif; ?>


					<form class="renew-account float-left mr-1" method="POST" action="<?php echo e(route('admin.users.licenses.renew'), false); ?>">
						<?php echo csrf_field(); ?>
						<input type="hidden" name="account_id" value="<?php echo e($account->id, false); ?>">

						<button type="submit" class="btn btn-success">
							<?php echo e(__('Renew access'), false); ?>

						</button>
					</form>



				</div>

			</div>
		</div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<!-- 33028645 -->


<?php $__env->startSection('scripts'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('theme/vendor/datatables/jquery.dataTables.min.js'), false); ?>"></script>
<script src="<?php echo e(asset('theme/vendor/datatables/dataTables.bootstrap4.min.js'), false); ?>"></script>

<?php if(app()->getLocale() == 'ru'): ?>
<?php ($locale = "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Russian.json"); ?>
<?php else: ?>
<?php ($locale = "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/English.json"); ?>
<?php endif; ?>

<!-- Page level custom scripts -->
<script>
	$(document).ready(function() {
		$('#licenses').DataTable({
			"language": {
				"url": "<?php echo e($locale, false); ?>"
			},
			"order": false
		});

		$('#window-account-number').on('show.bs.modal', function(e) {
			$('#account_id').val($(e.relatedTarget).attr('num'));
		})

		$('.to-appoint').on('click', function() {
			$.ajaxSetup({
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				}
			});
			$.ajax({
				url: "<?php echo e(route('to_appoint'), false); ?>",
				type: 'post',
				data: {
					'id': $('#account_id').val(),
					'number': $('#account_number').val()
				},
				success: function(data) {
					console.log(data);

					if (data.error) {
						$('.account_number_error strong').html(data.error[0]);
						$('.account_number_error').show();
						$('.account_number_input_error').addClass('is-invalid');
					} else {
						location.reload();

						// $('#window-account-number').modal('hide');
						// $('.account_number_error').hide();
						// $('.account_number_input_error').removeClass('is-invalid');
					}

				},
				error: function(error) {
					console.log(error);
				}
			});
		});

		$("body").on('submit', '.block-account', function(e) {
			e.preventDefault();
			var form = $(this);
			$.ajax({
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: form.serialize(),
				success: function(data) {
					if (data.success) {
						if (data.value) {
							$('.unblock-button').removeAttr('hidden');
							$('.block-button').attr('hidden', 'hidden');
						} else {
							$('.block-button').removeAttr('hidden');
							$('.unblock-button').attr('hidden', 'hidden');
						}
					}
					console.log(data);
				}
			});
		});

		$("body").on('submit', '.detach-account', function(e) {
			e.preventDefault();
			var form = $(this);
			$.ajax({
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: form.serialize(),
				success: function(data) {
					location.reload();
				}
			});
		});

		$("body").on('submit', '.renew-account', function(e) {
			e.preventDefault();
			var form = $(this);
			$.ajax({
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: form.serialize(),
				success: function(data) {
					location.reload();
				}
			});
		});

	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/admin/licenses/index.blade.php ENDPATH**/ ?>