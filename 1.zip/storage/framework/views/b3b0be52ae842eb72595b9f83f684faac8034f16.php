<?php $__env->startSection('content'); ?>

<!-- <?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
	<?php echo e(session('status'), false); ?>

</div>
<?php endif; ?> -->

<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Profile'), false); ?></h1>
</div>


<?php if(!auth()->user()->phone): ?>
<div class="alert alert-danger alert-danger-phone" role="alert">
	<?php echo e(__('Confirm your phone number to get started'), false); ?>

</div>
<?php endif; ?>


<div class="toast hide" role="alert" aria-live="assertive" aria-atomic="true" id="toast" data-delay="2000" style="position: absolute; top: 85px; right: 20px; z-index: 1000;">
	<div class="toast-header">
		<svg class="bd-placeholder-img rounded mr-2" width="20" height="20" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img">
			<rect width="100%" height="100%" fill="#007aff"></rect>
		</svg>

		<strong class="mr-auto"><?php echo e(__('Copying'), false); ?></strong>
		<!-- <small>только что</small> -->
		<button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
	</div>
	<div class="toast-body">
		<?php echo e(__('Successfully!'), false); ?>

	</div>
</div>


<div class="row justify-content-center">
	<div class="col-md-6">
		<div class="card mb-4">
			<div class="card-header">
				<h6 class="m-0 font-weight-bold text-primary pt-3"><?php echo e(__('Personal data'), false); ?></h6>
			</div>

			<div class="card-body">

				<!-- Смена пароля. Добавление аватарки.
				телефон (с верификацией) -->


				<?php if(session('personal_data_success')): ?>
				<div class="alert alert-success" role="alert">
					<?php echo e(session('personal_data_success'), false); ?>

				</div>
				<?php endif; ?>

				<form class="user" method="POST" action="<?php echo e(route('personal_data'), false); ?>">
					<?php echo csrf_field(); ?>

					<div class="form-group">
						<label for="email"><?php echo e(__('E-mail'), false); ?></label>

						<input id="email" type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(auth()->user()->email, false); ?>" disabled>

						<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message, false); ?></strong>
						</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>

					<div class="form-group">
						<label for="first_name"><?php echo e(__('First Name'), false); ?></label>

						<input id="first_name" type="text" class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="first_name" value="<?php echo e(auth()->user()->first_name, false); ?>">

						<?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message, false); ?></strong>
						</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>

					<div class="form-group">
						<label for="last_name"><?php echo e(__('Last Name'), false); ?></label>

						<input id="last_name" type="text" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="last_name" value="<?php echo e(auth()->user()->last_name, false); ?>">

						<?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message, false); ?></strong>
						</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>



					<div class="form-group">
						<label for="telegram"><?php echo e(__('Telegram'), false); ?></label>

						<div class="input-group mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text" id="basic-telegram">@</span>
							</div>
							<input aria-describedby="basic-telegram" id="telegram" type="text" class="form-control <?php $__errorArgs = ['telegram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="telegram" value="<?php echo e(auth()->user()->telegram, false); ?>">
						</div>

						<?php $__errorArgs = ['telegram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message, false); ?></strong>
						</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>

					<div class="form-group">
						<label for="whatsapp"><?php echo e(__('WhatsApp'), false); ?></label>


						<input id="whatsapp" type="text" class="form-control <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="whatsapp" value="<?php echo e(auth()->user()->whatsapp, false); ?>">

						<?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message, false); ?></strong>
						</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>

					<div class="form-group">
						<label for="viber"><?php echo e(__('Viber'), false); ?></label>


						<input id="viber" type="text" class="form-control <?php $__errorArgs = ['viber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="viber" value="<?php echo e(auth()->user()->viber, false); ?>">


						<?php $__errorArgs = ['viber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message, false); ?></strong>
						</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>

					<div class="form-group">
						<label for="vk"><?php echo e(__('Vkontakte'), false); ?></label>


						<div class="input-group mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text" id="basic-vk">https://vk.com/</span>
							</div>
							<input aria-describedby="basic-vk" id="vk" type="text" class="form-control <?php $__errorArgs = ['vk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="vk" value="<?php echo e(auth()->user()->vk, false); ?>">
						</div>


						<?php $__errorArgs = ['vk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message, false); ?></strong>
						</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>

					<div class="form-group">
						<label for="fb"><?php echo e(__('Facebook'), false); ?></label>

						<div class="input-group mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text" id="basic-fb">https://www.facebook.com/</span>
							</div>
							<input aria-describedby="basic-fb" id="fb" type="text" class="form-control <?php $__errorArgs = ['fb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="fb" value="<?php echo e(auth()->user()->fb, false); ?>">
						</div>

						<?php $__errorArgs = ['fb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message, false); ?></strong>
						</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>

					<div class="form-group">
						<label for="instagram"><?php echo e(__('Instagram'), false); ?></label>

						<div class="input-group mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text" id="basic-instagram">https://www.instagram.com/</span>
							</div>
							<input aria-describedby="basic-instagram" id="instagram" type="text" class="form-control <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="instagram" value="<?php echo e(auth()->user()->instagram, false); ?>">
						</div>

						<?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message, false); ?></strong>
						</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>



					<div class="form-group">
						<button type="submit" class="btn btn-primary">
							<?php echo e(__('Save'), false); ?>

						</button>
					</div>
				</form>


			</div>
		</div>
	</div>


	<div class="col-md-6">

		<div class="card mb-4">
			<div class="card-header">
				<h6 class="m-0 font-weight-bold text-primary pt-3"><?php echo e(__('Telegram bot'), false); ?></h6>
			</div>

			<div class="card-body">

				<div class="form-group">
					<label><?php echo e(__('Link'), false); ?></label>

					<div class="input-group is-invalid">
						<input id="bot_link" type="text" class="form-control" value="<?php echo e(auth()->user()->tg_bot(), false); ?>">
						<div class="input-group-append">
							<button class="btn btn-outline-secondary" type="button" onclick="copytext('#bot_link')"><?php echo e(__('Copy'), false); ?></button>
						</div>
					</div>

				</div>

			</div>
		</div>

		<div class="card mb-4">
			<div class="card-header">
				<h6 class="m-0 font-weight-bold text-primary pt-3"><?php echo e(__('Phone number'), false); ?></h6>
			</div>

			<div class="card-body">

				<div class="alert alert-success phone_changed" role="alert">
					<?php echo e(__('Phone number has been successfully changed'), false); ?>

				</div>



				<div class="mb-3 current_phone_number"><?php echo e(__('Current phone number'), false); ?>: <b><span>+<?php echo e(auth()->user()->phone, false); ?></span></b></div>


				<form method="POST">
					<?php echo csrf_field(); ?>

					<div class="form-group new_phone">
						<label for="phone"><?php echo e(__('New phone'), false); ?></label>

						<input id="phone" type="text" class="phone_mask form-control phone_input_error" name="phone">

						<span class="invalid-feedback phone_text_error" role="alert">
							<strong></strong>
						</span>

					</div>

					<div class="form-group sms_code">
						<label for="text"><?php echo e(__('Code from sms'), false); ?></label>
						<input id="phone_code" type="text" class="form-control code_input_error" name="phone_code">

						<span class="invalid-feedback code_text_error" role="alert">
							<strong></strong>
						</span>
					</div>

				</form>

				<div class="form-group sms_code">
					<button class="btn btn-primary check_sms_code"><?php echo e(__('Save phone'), false); ?></button>
				</div>

				<div class="form-group new_phone">
					<div class="timer"><span></span></div>
					<button class="btn btn-success send_sms_code"><?php echo e(__('Send sms code'), false); ?></button>
				</div>

			</div>
		</div>




		<div class="card mb-4">
			<div class="card-header">
				<h6 class="m-0 font-weight-bold text-primary pt-3"><?php echo e(__('Change password'), false); ?></h6>
			</div>

			<div class="card-body">

				<?php if(session('change_password_success')): ?>
				<div class="alert alert-success" role="alert">
					<?php echo e(session('change_password_success'), false); ?>

				</div>
				<?php endif; ?>

				<form class="user" method="POST" action="<?php echo e(route('change_password'), false); ?>">
					<?php echo csrf_field(); ?>

					<div class="form-group">
						<label for="current_password"><?php echo e(__('Current Password'), false); ?></label>

						<input id="current_password" type="password" class="form-control <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="current_password">

						<?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message, false); ?></strong>
						</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>

					<div class="form-group">
						<label for="new_password"><?php echo e(__('New Password'), false); ?></label>

						<input id="new_password" type="password" class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="new_password">

						<?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message, false); ?></strong>
						</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>

					<div class="form-group">
						<label for="new_password_confirmation"><?php echo e(__('Confirm Password'), false); ?></label>

						<input id="new_password_confirmation" type="password" class="form-control <?php $__errorArgs = ['new_password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="new_password_confirmation">

						<?php $__errorArgs = ['new_password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message, false); ?></strong>
						</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>


					<div class="form-group">
						<button type="submit" class="btn btn-primary">
							<?php echo e(__('Change password'), false); ?>

						</button>
					</div>
				</form>


			</div>
		</div>


		<div class="card mb-4">
			<div class="card-header">
				<h6 class="m-0 font-weight-bold text-primary pt-3"><?php echo e(__('Change avatar'), false); ?></h6>
			</div>

			<div class="card-body">

				<?php if(session('change_avatar_success')): ?>
				<div class="alert alert-success" role="alert">
					<?php echo e(session('change_avatar_success'), false); ?>

				</div>
				<?php endif; ?>

				<?php if(auth()->user()->getMedia('avatars')->first()): ?>
				<div class="my-3">
					<img width="60" height="60" class="img-profile rounded-circle" src="<?php echo e(auth()->user()->getMedia('avatars')->first()->getUrl('thumb'), false); ?>">
				</div>
				<?php endif; ?>

				<form class="user" method="POST" action="<?php echo e(route('change_avatar'), false); ?>" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>

					<div class="form-group">
						<div class="custom-file">
							<input type="file" class="custom-file-input" id="avatar" name="avatar">
							<label class="custom-file-label" for="avatar"><?php echo e(__('Avatar'), false); ?></label>
						</div>

						<?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message, false); ?></strong>
						</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>

					<!-- <div class="form-group">
						<label for="avatar"><?php echo e(__('Avatar'), false); ?></label>

						<input id="avatar" type="file" class="form-control <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="avatar">

					</div> -->

					<div class="form-group">
						<button type="submit" class="btn btn-primary">
							<?php echo e(__('Change'), false); ?>

						</button>
					</div>
				</form>


			</div>
		</div>

	</div>




</div>

<style>
	.custom-file-label::after {
		content: "<?php echo e(__('Browse'), false); ?>"
	}
</style>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>

<script src="https://cdn.jsdelivr.net/npm/jquery.maskedinput@1.4.1/src/jquery.maskedinput.min.js" type="text/javascript"></script>

<?php if(auth()->user()->phone): ?>
<script>
	$('.current_phone_number').show();
</script>
<?php else: ?>
<script>
	$('.current_phone_number').hide();
</script>
<?php endif; ?>


<script>
	function copytext(el) {
		console.log(1);
		var $tmp = $("<textarea>");
		$("body").append($tmp);
		$tmp.val($(el).val()).select();
		document.execCommand("copy");
		$tmp.remove();
		console.log(2);
		$('#toast').toast('show');
	}

	$('input#instagram').on('change', function() {
		var value = $(this).val();
		value = value.replace('https://', '');
		value = value.replace('http://', '');
		value = value.replace('www.', '');
		value = value.replace('instagram.com/', '');
		$(this).val(value);
	});

	$('input#fb').on('change', function() {
		var value = $(this).val();
		value = value.replace('https://', '');
		value = value.replace('http://', '');
		value = value.replace('www.', '');
		value = value.replace('facebook.com/', '');
		$(this).val(value);
	});

	$('input#vk').on('change', function() {
		var value = $(this).val();
		value = value.replace('https://', '');
		value = value.replace('http://', '');
		value = value.replace('www.', '');
		value = value.replace('vk.com/', '');
		$(this).val(value);
	});

	$(".phone_mask").mask("+9 (999) 999-9999");

	$('.phone_changed').hide();
	$('.sms_code').hide();

	$('.phone_text_error').hide();
	$('.phone_input_error').removeClass('is-invalid');

	$('.code_text_error').hide();
	$('.code_input_error').removeClass('is-invalid');

	$('.send_sms_code').on('click', function() {
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});
		$.ajax({
			url: "<?php echo e(route('send_sms_code_new_phone'), false); ?>",
			type: 'post',
			data: {
				'phone': $('#phone').val()
			},
			success: function(data) {
				console.log(data);
				$('.phone_text_error').hide();
				$('.sms_code').hide();
				$('.new_phone').show();
				$('.phone_input_error').removeClass('is-invalid');
				if (data.error) {
					$('.phone_text_error strong').html(data.error[0]);
					$('.phone_text_error').show();
					$('.phone_input_error').addClass('is-invalid');
				} else {
					$('.sms_code').show();
					$('.new_phone').hide();
				}
			},
			error: function(error) {
				console.log(error);
			}
		});
	});



	$('.check_sms_code').on('click', function() {
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});
		$.ajax({
			url: "<?php echo e(route('check_sms_code_new_phone'), false); ?>",
			type: 'post',
			data: {
				'phone_code': $('#phone_code').val()
			},
			success: function(data) {
				console.log(data);
				$('.code_text_error').hide();
				$('.new_phone').hide();
				$('.sms_code').show();
				$('.code_input_error').removeClass('is-invalid');
				if (data.error) {
					$('.code_text_error strong').html(data.error[0]);
					$('.code_text_error').show();
					$('.code_input_error').addClass('is-invalid');
				} else {
					$('.new_phone').hide();
					$('.sms_code').hide();

					$('.phone_changed').show();
					$('.current_phone_number span').html(data.phone);
					$('.current_phone_number').show();

					$('.alert-danger-phone').hide();
				}
			},
			error: function(error) {
				console.log(error);
			}
		});

		function startCountdown(startFrom) {
			countdown = $('.timer span');
			countdown.text('00:' + startFrom);
			countdown.show();
			$('.send-code-link').hide();
			timer = setInterval(function() {
				startFrom = parseInt(startFrom - 1);
				if (startFrom < 10) {
					startFrom = '0' + startFrom;
				}
				countdown.text('00:' + startFrom);
				if (startFrom <= 0) {
					clearInterval(timer);
					$('.send-code-link').show();
					countdown.hide();
				}
			}, 1000);
		}
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/profile.blade.php ENDPATH**/ ?>