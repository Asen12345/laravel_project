<?php $__env->startSection('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><?php echo e(__('News'), false); ?> – <?php echo e($article->title, false); ?></h1>
</div>

<!-- Row -->
<div class="row">
	<div class="col-lg-8">

		<div class="card mb-4 py-4 px-5">

			<div class="row">
				<div class="col-md-12">
					<div style="color: rgba(0,0,0,0.3);" class="mb-3"><?php echo e(__('Published'), false); ?>: <?php echo e(date('d.m.Y H:i', strtotime($article->created_at)), false); ?></div>

					<?php if($article->getFirstMediaUrl('images', 'thumb_big')): ?>
					<img style="float: left;" class="mr-4 mb-4" width="200" height="200" src="<?php echo e($article->getFirstMediaUrl('images', 'thumb_big'), false); ?>">
					<?php endif; ?>

					<div><?php echo $article->text; ?></div>
				</div>


			</div>
		</div>


	</div>
</div>
<!--Row-->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>


<!-- Page level custom scripts -->
<script>
	$(document).ready(function() {



	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/new.blade.php ENDPATH**/ ?>