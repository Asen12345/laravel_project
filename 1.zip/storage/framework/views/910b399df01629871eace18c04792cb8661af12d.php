<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header"><b><?php echo e(__('Verify Your Email Address'), false); ?></b></div>

				<div class="card-body">
					<?php if(session('resent')): ?>
					<div class="alert alert-success" role="alert">
						<?php echo e(__('A fresh verification link has been sent to your email address.'), false); ?>

					</div>
					<?php endif; ?>

					<?php echo e(__('Before proceeding, please check your email for a verification link.'), false); ?>

					<?php echo e(__('If you did not receive the email'), false); ?>,
					<form class="d-inline" method="POST" action="<?php echo e(route('verification.resend'), false); ?>">
						<?php echo csrf_field(); ?>
						<button type="submit" class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('click here to request another'), false); ?></button>.
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/auth/verify.blade.php ENDPATH**/ ?>