<?php $__env->startSection('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><?php echo e(__('News'), false); ?></h1>
</div>

<!-- Row -->
<div class="row">
	<div class="col-lg-8">

		<?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<div class="card mb-4 py-4 px-5">

			<div class="row">
				<div class="col-md-4">

					<?php if($article->getFirstMediaUrl('images', 'thumb_middle')): ?>
					<img width="100" height="100" src="<?php echo e($article->getFirstMediaUrl('images', 'thumb_middle'), false); ?>">
					<?php endif; ?>

				</div>
				<div class="col-md-8">
					<h4 class="mb-3"><?php echo e($article->title, false); ?></h4>
					<div><?php echo e($article->description, false); ?></div>
					<div class="mt-3 d-flex flex-row align-items-center justify-content-end">
						<a class="btn btn-success" href="<?php echo e(route('new', $article->id), false); ?>"><?php echo e(__('Read full text'), false); ?></a>
					</div>
				</div>


			</div>
		</div>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		<?php endif; ?>

	</div>
</div>
<!--Row-->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>


<!-- Page level custom scripts -->
<script>
	$(document).ready(function() {



	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/news.blade.php ENDPATH**/ ?>