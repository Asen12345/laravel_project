<?php $__env->startSection('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Payments'), false); ?></h1>
</div>

<!-- Row -->
<div class="row">
	<!-- DataTable -->
	<div class="col-lg-12">
		<div class="card mb-4">
			<!-- <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"> -->
			<!-- <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('My finances'), false); ?></h6> -->
			<!-- </div> -->

			<!-- <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
				<div></div>


			</div> -->

			<div class="row mt-4 mx-2 mb-2">
				<div class="col-md-4 col-lg-3 col-xl-2">
					<div class="form-group">
						<label><?php echo e(__('Type operation'), false); ?></label>
						<select class="form-control form-control-sm type-operation">
							<option value="0"><?php echo e(__('All'), false); ?></option>
							<option value="1"><?php echo e(__('Cash receipts'), false); ?></option>
							<option value="2"><?php echo e(__('Withdraw'), false); ?></option>
							<option value="3"><?php echo e(__('Buying a robot'), false); ?></option>
							<option value="4"><?php echo e(__('Sale of robots'), false); ?></option>
							<option value="5"><?php echo e(__('Binar accrual'), false); ?></option>

							<option value="6"><?php echo e(__('Investor withdraw'), false); ?></option>
							<option value="7"><?php echo e(__('Investor accrual'), false); ?></option>

						</select>
					</div>
				</div>
				<div class="col-md-4 col-lg-3 col-xl-2">
					<div class="form-group">
						<label><?php echo e(__('Status operation'), false); ?></label>
						<select class="form-control form-control-sm status-operation">
							<option value="4"><?php echo e(__('All'), false); ?></option>
							<option value="0"><?php echo e(__('In process'), false); ?></option>
							<option value="1"><?php echo e(__('Completed'), false); ?></option>
							<option value="2"><?php echo e(__('Canceled'), false); ?></option>
							<option value="3"><?php echo e(__('Rejected'), false); ?></option>
						</select>
					</div>
				</div>
			</div>







			<div class="table-responsive p-3">
				<table class="table align-items-center table-flush table-hover" id="finances">
					<thead class="thead-light">
						<tr>
							<th><?php echo e(__('Date'), false); ?></th>
							<th><?php echo e(__('Amount'), false); ?></th>
							<th><?php echo e(__('Description'), false); ?></th>
							<th style="display: none;"><?php echo e(__('Type'), false); ?></th>
							<th><?php echo e(__('Status'), false); ?></th>
							<th style="display: none;"><?php echo e(__('Status'), false); ?></th>
							<th style="display: none;"><?php echo e(__('Table'), false); ?></th>
							<th></th>
						</tr>
					</thead>
					<tbody>

						<?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td>
								<?php if($payment->created_at): ?>
								<a href="" data-toggle="modal" data-target="#window-detail<?php echo e($payment->id, false); ?>" id="#modalCenter"><?php echo e(date('d.m.Y H:i', strtotime($payment->created_at)), false); ?></a>
								<?php else: ?>
								–
								<?php endif; ?></td>
							<td>
								<?php if($payment->amount < 0): ?> <span style="color: red;"><?php echo e(number_format($payment->amount, 0, " ", " "), false); ?> $</span>
									<?php else: ?>
									<span style="color: #00b300;"><?php echo e(number_format($payment->amount, 0, " ", " "), false); ?> $</span>
									<?php endif; ?>

							</td>
							<td>
								<?php echo e($payment->status_title(), false); ?>

							</td>
							<td style="display: none;">
								<?php echo e($payment->type, false); ?>

							</td>
							<td>

								<?php if($payment->status == 0): ?>
								<span class="badge badge-info"><?php echo e(__('In process'), false); ?></span>
								<?php endif; ?>
								<?php if($payment->status == 1): ?>
								<span class="badge badge-success"><?php echo e(__('Completed'), false); ?></span>
								<?php endif; ?>
								<?php if($payment->status == 2): ?>
								<span class="badge badge-warning"><?php echo e(__('Canceled'), false); ?></span>
								<?php endif; ?>
								<?php if($payment->status == 3): ?>
								<span class="badge badge-danger"><?php echo e(__('Rejected'), false); ?></span>
								<?php endif; ?>
							</td>
							<td style="display: none;">
								<?php echo e($payment->status, false); ?>

							</td>
							<td style="display: none;">
								<?php echo e($payment->table, false); ?>

							</td>
							<td>
								<?php if($payment->status == 0 && $payment->type == 2): ?>
								<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#window-withdraw<?php echo e($payment->id, false); ?>" id="#modalCenter">
									<?php echo e(__('Withdraw'), false); ?>

								</button>
								<?php endif; ?>
							</td>



						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<?php endif; ?>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<!--Row-->





<?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>




<div class="modal fade" id="window-detail<?php echo e($payment->id, false); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('Payment details'), false); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Date'), false); ?></div>
					<div class="col-md-6 text-right"><?php echo e(date('d.m.Y H:i', strtotime($payment->created_at)), false); ?></div>
				</div>

				<?php if($payment->user): ?>
				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('User'), false); ?></div>
					<div class="col-md-6 text-right">
						<a target="_blank" href="<?php echo e(route('admin.users.info', $payment->user->id), false); ?>"><?php echo e($payment->user->email, false); ?></a>
					</div>
				</div>
				<?php endif; ?>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Amount'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php if($payment->amount < 0): ?> <span style="color: red;"><?php echo e(number_format($payment->amount, 0, " ", " "), false); ?> $</span>
							<?php else: ?>
							<span style="color: #00b300;"><?php echo e(number_format($payment->amount, 0, " ", " "), false); ?> $</span>
							<?php endif; ?>
					</div>
				</div>

				<?php if($payment->fee): ?>
				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Fee'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php echo e(number_format($payment->fee, 0, " ", " "), false); ?> $
					</div>
				</div>
				<?php endif; ?>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Total'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php ($total = $payment->amount - $payment->fee); ?>
						<?php echo e($total, false); ?> $
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Type'), false); ?></div>
					<div class="col-md-6 text-right"><?php echo e($payment->status_title(), false); ?></div>
				</div>

				<?php if($payment->payee): ?>
				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Payee'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php echo e($payment->payee, false); ?>

					</div>
				</div>
				<?php endif; ?>

				<?php if($payment->payer): ?>
				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Payer'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php echo e($payment->payer, false); ?>

					</div>
				</div>
				<?php endif; ?>

				<?php if($payment->payment_system): ?>
				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Payment system'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php echo e($payment->payment_system, false); ?>

					</div>
				</div>
				<?php endif; ?>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Confirm date'), false); ?></div>
					<div class="col-md-6 text-right"><?php echo e(date('d.m.Y H:i', strtotime($payment->confirm_date)), false); ?></div>
				</div>

				<form class="batcn-execute" method="POST" action="<?php echo e(route('admin.payments.execute'), false); ?>">
					<?php echo csrf_field(); ?>
					<input name="payment_id" value="<?php echo e($payment->id, false); ?>" type="hidden">
					<div class="my-3 row">
						<div class="col-md-6"><?php echo e(__('Batcn'), false); ?></div>
						<div class="col-md-6 text-right">
							<?php if($payment->status != 1): ?>
							<input id="batcn" type="text" class="form-control batcn_input_error" name="batcn" value="">
							<span class="invalid-feedback batcn_error" role="alert">
								<strong></strong>
							</span>
							<?php else: ?>
							<?php echo e($payment->batcn, false); ?>

							<?php endif; ?>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-success" <?php if($payment->status == 1): ?> hidden <?php endif; ?>><?php echo e(__('Execute'), false); ?></button>
						<button class="btn btn-danger" <?php if($payment->status != 1): ?> hidden <?php endif; ?>><?php echo e(__('Cancel'), false); ?></button>
					</div>
				</form>

			</div>
		</div>
	</div>
</div>




<!-- Modal Center -->
<div class="modal fade" id="window-withdraw<?php echo e($payment->id, false); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('Withdraw'), false); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">

				<?php if($payment->user): ?>
				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Wallet'), false); ?></div>
					<div class="col-md-6 text-right"><?php echo e($payment->user->purse, false); ?></div>
				</div>
				<?php endif; ?>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Amount'), false); ?></div>
					<div class="col-md-6 text-right"><?php echo e($payment->amount, false); ?></div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Fee'), false); ?></div>
					<div class="col-md-6 text-right"><?php echo e($payment->fee, false); ?></div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Total'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php ($total = $payment->amount - $payment->fee); ?>
						<?php echo e($total, false); ?>

					</div>
				</div>



				<form class="batcn-execute" method="POST" action="<?php echo e(route('admin.payments.execute'), false); ?>">
					<?php echo csrf_field(); ?>
					<input name="payment_id" value="<?php echo e($payment->id, false); ?>" type="hidden">
					<div class="my-3 row">
						<div class="col-md-6"><?php echo e(__('Batcn'), false); ?></div>
						<div class="col-md-6 text-right">
							<?php if($payment->status != 1): ?>
							<input id="batcn" type="text" class="form-control batcn_input_error" name="batcn" value="">
							<span class="invalid-feedback batcn_text_error" role="alert">
								<strong></strong>
							</span>
							<?php else: ?>
							<?php echo e($payment->batcn, false); ?>

							<?php endif; ?>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-success" <?php if($payment->status == 1): ?> hidden <?php endif; ?>><?php echo e(__('Execute'), false); ?></button>
						<button class="btn btn-danger" <?php if($payment->status != 1): ?> hidden <?php endif; ?>><?php echo e(__('Cancel'), false); ?></button>
					</div>
				</form>


			</div>
		</div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<!-- 33028645 -->


<?php $__env->startSection('scripts'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('theme/vendor/datatables/jquery.dataTables.min.js'), false); ?>"></script>
<script src="<?php echo e(asset('theme/vendor/datatables/dataTables.bootstrap4.min.js'), false); ?>"></script>

<?php if(app()->getLocale() == 'ru'): ?>
<?php ($locale = "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Russian.json"); ?>
<?php else: ?>
<?php ($locale = "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/English.json"); ?>
<?php endif; ?>

<!-- Page level custom scripts -->
<script>
	$(document).ready(function() {

		// Функция показать ошибку
		function error_field(field, error = true, text) {
			if (error) {
				$('.' + field + '_text_error strong').html(text);
				$('.' + field + '_text_error').show();
				$('.' + field + '_input_error').addClass('is-invalid');
			} else {
				$('.' + field + '_text_error strong').html('');
				$('.' + field + '_text_error').hide();
				$('.' + field + '_input_error').removeClass('is-invalid');
			}
		}

		// Таблица
		var payments = $('#finances').DataTable({
			"language": {
				"url": "<?php echo e($locale, false); ?>"
			},
			"order": false
		});

		$('.type-operation').on('change', function() {
			payments.draw();
		});

		$('.status-operation').on('change', function() {
			payments.draw();
		});

		/* Custom filtering function which will search data in column four between two values */
		$.fn.dataTable.ext.search.push(
			function(settings, data, dataIndex) {

				var type_filter = parseFloat($('.type-operation').val());
				var status_filter = parseFloat($('.status-operation').val());

				var type = parseFloat(data[3]);
				var amount = parseFloat(data[1]);
				var status = parseFloat(data[5]);
				var table = data[6];

				if (status_filter == 4 || status_filter == status) { // если статус платежа подходит
					switch (type_filter) {
						case 0:
							return true;
							break;
						case 1:
							if (table == 'payments' && ((type == 1) || (type == 3 && amount > 0))) {
								return true;
							}
							break;
						case 2:
							if (table == 'payments' && ((type == 2) || (type == 3 && amount < 0))) {
								return true;
							}
							break;
						case 3:
							if (table == 'payments' && ((type == 4) || (type == 5) || (type == 6))) {
								return true;
							}
							break;
						case 4:
							if (table == 'payments' && ((type == 7) || (type == 8))) {
								return true;
							}
							break;
						case 5:
							if (table == 'payments' && (type >= 10 && type < 20)) {
								return true;
							}
							break;
						case 6:
							if (table == 'investor_payments' && type == 2) {
								return true;
							}
							break;
						case 7:
							if (table == 'investor_payments' && type == 1) {
								return true;
							}
							break;
					}
				}

				return false;
			}
		);


		$("body").on('submit', '.batcn-execute', function(e) {
			e.preventDefault();
			var form = $(this);
			$.ajax({
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: form.serialize(),
				success: function(data) {

					error_field('batcn', false);

					if (data.success) {
						location.reload();
					}

					if (data.error) {
						if (data.error.batcn) {
							error_field('batcn', true, data.error.batcn[0]);
						}
					}

					console.log(data);
				}
			});
		});

	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/admin/payments/index.blade.php ENDPATH**/ ?>