<?php $__env->startSection('content'); ?>

<!-- <?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
	<?php echo e(session('status'), false); ?>

</div>
<?php endif; ?> -->

<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Curator'), false); ?></h1>
</div>


<div class="row justify-content-center2">
	<div class="col-md-6">
		<div class="card mb-4">
			<!-- <div class="card-header">
				<h6 class="m-0 font-weight-bold text-primary pt-3"><?php echo e(__('Curator'), false); ?></h6>
			</div> -->

			<div class="card-body">


				<div class="mb-5">
					<?php if($curator->getMedia('avatars')->first()): ?>
					<?php ($avatar = $curator->getMedia('avatars')->first()->getUrl('thumb_middle')); ?>
					<?php else: ?>
					<?php ($avatar = asset('theme/img/boy.png')); ?>
					<?php endif; ?>

					<div class="my-3 row">
						<div class="col-md-4">
							<img width="100" height="100" class="img-profile rounded-circle" src="<?php echo e($avatar, false); ?>">
						</div>

						<div class="col-md-8 d-flex align-items-center">
							<?php echo e($curator->first_name, false); ?><br /><?php echo e($curator->last_name, false); ?>

						</div>
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('Activity'), false); ?></div>
					<div class="col-md-8 text-right2">
						<?php echo $curator->status(); ?>

						
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('Tariff'), false); ?></div>
					<div class="col-md-8 text-right2">
						<?php if($curator->binar): ?>
						<?php if($curator->binar->type == 1): ?>
						Standard
						<?php endif; ?>
						<?php if($curator->binar->type == 2): ?>
						Gold
						<?php endif; ?>
						<?php if($curator->binar->type == 3): ?>
						VIP
						<?php endif; ?>

						<?php else: ?>
						–
						<?php endif; ?>
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('Referrals count'), false); ?></div>
					<div class="col-md-8 text-right2"><?php echo e($curator->count_partners(), false); ?></div>
				</div>


				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('Registration date'), false); ?></div>
					<div class="col-md-8 text-right2"><?php echo e(date('d.m.Y', strtotime($curator->created_at)), false); ?></div>
				</div>


				<h4 class="mt-5 mb-4"><?php echo e(__('Contacts'), false); ?></h4>

				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('Email'), false); ?></div>
					<div class="col-md-8 text-right2"><a href="mailto:<?php echo e($curator->email, false); ?>"><?php echo e($curator->email, false); ?></a></div>
				</div>

				<?php if($curator->phone): ?>
				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('Phone'), false); ?></div>
					<div class="col-md-8 text-right2"><a href"tel:+<?php echo e($curator->phone, false); ?>"><?php echo e($curator->phoneNumber(), false); ?></a></div>
				</div>
				<?php endif; ?>

				<?php if($curator->vk): ?>
				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('Vkontakte'), false); ?></div>
					<div class="col-md-8 text-right2"><a target="_blank" href="https://vk.com/<?php echo e($curator->vk, false); ?>">https://vk.com/<?php echo e($curator->vk, false); ?></a></div>
				</div>
				<?php endif; ?>

				<?php if($curator->instagram): ?>
				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('Instagram'), false); ?></div>
					<div class="col-md-8 text-right2">
						<a target="_blank" href="https://www.instagram.com/<?php echo e($curator->instagram, false); ?>">https://www.instagram.com/<?php echo e($curator->instagram, false); ?></a>
					</div>
				</div>
				<?php endif; ?>

				<?php if($curator->fb): ?>
				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('Facebook'), false); ?></div>
					<div class="col-md-8 text-right2">
						<a target="_blank" href="https://www.facebook.com/<?php echo e($curator->fb, false); ?>">https://www.facebook.com/<?php echo e($curator->fb, false); ?></a>
					</div>
				</div>
				<?php endif; ?>

				<?php if($curator->telegram): ?>
				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('Telegram'), false); ?></div>
					<div class="col-md-8 text-right2">
						<a target="_blank" href="https://t.me/<?php echo e($curator->telegram, false); ?>"><?php echo e('@' . $curator->telegram, false); ?></a>
					</div>
				</div>
				<?php endif; ?>

				<?php if($curator->whatsapp): ?>
				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('WhatsApp'), false); ?></div>
					<div class="col-md-8 text-right2">
						<a target="_blank" href="https://wa.me/<?php echo e($curator->whatsapp, false); ?>"><?php echo e($curator->whatsapp, false); ?></a>
					</div>
				</div>
				<?php endif; ?>

				<?php if($curator->viber): ?>
				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('Viber'), false); ?></div>
					<div class="col-md-8 text-right2">
						<a target="_blank" href="viber://chat?number=<?php echo e($curator->viber, false); ?>"><?php echo e($curator->viber, false); ?></a>
					</div>
				</div>
				<?php endif; ?>



			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/curator.blade.php ENDPATH**/ ?>