<?php echo e($slot, false); ?>

<?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>