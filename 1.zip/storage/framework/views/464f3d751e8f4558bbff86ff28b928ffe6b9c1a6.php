<?php echo e($slot, false); ?>: <?php echo e($url, false); ?>

<?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>