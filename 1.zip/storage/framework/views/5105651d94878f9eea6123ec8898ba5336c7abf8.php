<?php $__env->startSection('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Robots'), false); ?></h1>
</div>

<!-- Row -->
<div class="row">
	<div class="col-lg-8">

		<?php $__empty_1 = true; $__currentLoopData = $robots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $robot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<div class="card mb-4 py-4 px-5">

			<div class="row">
				<div class="col-md-4">
					<?php if($robot->getFirstMediaUrl('images', 'thumb_big')): ?>
					<img style="float: left;" class="mr-4 mb-4" width="200" height="200" src="<?php echo e($robot->getFirstMediaUrl('images', 'thumb_big'), false); ?>">
					<?php endif; ?>
				</div>
				<div class="col-md-8">
					<h4 class="mb-3"><?php echo e($robot->title, false); ?></h4>
					<div><?php echo e($robot->description, false); ?></div>
					<div class="mt-3 d-flex flex-row align-items-center justify-content-between">
						<span><?php echo e(__('Version'), false); ?>: <?php echo e($robot->version, false); ?></span>

						<?php if($robot->getFirstMediaUrl('zips')): ?>
						<div class="my-3">
							<a class="btn btn-success" target="_blank" href="<?php echo e($robot->getFirstMediaUrl('zips'), false); ?>"><?php echo e(__('Download'), false); ?></a>
						</div>
						<?php endif; ?>
					</div>
				</div>


			</div>
		</div>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		<?php endif; ?>

	</div>
</div>
<!--Row-->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>


<!-- Page level custom scripts -->
<script>
	$(document).ready(function() {



	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/robots.blade.php ENDPATH**/ ?>