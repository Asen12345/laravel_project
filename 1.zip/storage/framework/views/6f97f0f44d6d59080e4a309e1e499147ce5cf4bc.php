<?php $__env->startSection('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Investor finance'), false); ?> <span class="finance-investor">(<?php echo e(__('Balance'), false); ?>: <b><?php echo e(number_format(auth()->user()->investor_balance(), 0, " ", " "), false); ?></b> $)</span></h1>

	<button class="btn btn-danger" type="button" data-toggle="modal" data-target="#window-withdraw" id="#modalCenter">
		<?php echo e(__('Withdraw'), false); ?>

	</button>
</div>

<!-- Row -->
<div class="row">
	<!-- DataTable -->
	<div class="col-lg-12">
		<div class="card mb-4">
			<!-- 
			<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
				<div></div>

				<div>

				</div>
			</div> -->


			<div class="table-responsive p-3">
				<table class="table align-items-center table-flush table-hover" id="finances">
					<thead class="thead-light">
						<tr>
							<th><?php echo e(__('Date'), false); ?></th>
							<th><?php echo e(__('Amount'), false); ?></th>
							<th><?php echo e(__('Description'), false); ?></th>
							<th><?php echo e(__('Status'), false); ?></th>
						</tr>
					</thead>
					<!-- <tfoot>
						<tr>
							<th><?php echo e(__('Date'), false); ?></th>
							<th><?php echo e(__('Amount'), false); ?></th>
							<th><?php echo e(__('Description'), false); ?></th>
							<th><?php echo e(__('Status'), false); ?></th>
						</tr>
					</tfoot> -->
					<tbody>

						<?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td>
								<?php if($payment->created_at): ?>
								<?php echo e(date('d.m.Y H:i', strtotime($payment->created_at)), false); ?>

								<?php else: ?>
								–
								<?php endif; ?></td>
							<td>
								<?php if($payment->amount < 0): ?> <span style="color: red;"><?php echo e(number_format($payment->amount, 0, " ", " "), false); ?> $</span>
									<?php else: ?>
									<span style="color: #00b300;"><?php echo e(number_format($payment->amount, 0, " ", " "), false); ?> $</span>
									<?php endif; ?>

							</td>
							<td>
								<?php echo e($payment->status_title(), false); ?>


							</td>
							<td>

								<?php if($payment->status == 0): ?>
								<span class="badge badge-info"><?php echo e(__('In process'), false); ?></span>
								<?php endif; ?>
								<?php if($payment->status == 1): ?>
								<span class="badge badge-success"><?php echo e(__('Completed'), false); ?></span>
								<?php endif; ?>
								<?php if($payment->status == 2): ?>
								<span class="badge badge-warning"><?php echo e(__('Canceled'), false); ?></span>
								<?php endif; ?>
								<?php if($payment->status == 3): ?>
								<span class="badge badge-danger"><?php echo e(__('Rejected'), false); ?></span>
								<?php endif; ?>
							</td>

						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<?php endif; ?>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<!--Row-->


<!-- Вывести -->
<div class="modal fade" id="window-withdraw" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('Withdraw'), false); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">

			</div>
		</div>
	</div>
</div>


<style>
	.finance-investor {
		margin-left: 1rem;
		font-size: 0.8em;
		color: rgba(0, 0, 0, 0.4);
	}
</style>

<?php $__env->stopSection(); ?>

<!-- 33028645 -->


<?php $__env->startSection('scripts'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('theme/vendor/datatables/jquery.dataTables.min.js'), false); ?>"></script>
<script src="<?php echo e(asset('theme/vendor/datatables/dataTables.bootstrap4.min.js'), false); ?>"></script>

<?php if(app()->getLocale() == 'ru'): ?>
<?php ($locale = "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Russian.json"); ?>
<?php else: ?>
<?php ($locale = "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/English.json"); ?>
<?php endif; ?>

<!-- Page level custom scripts -->
<script>
	$(document).ready(function() {

		// Таблица
		$('#finances').DataTable({
			"language": {
				"url": "<?php echo e($locale, false); ?>"
			},
			"order": false
		});

		// Вывод денег
		$('#window-withdraw').on('show.bs.modal', function(e) {
			$.ajax({
				url: "<?php echo e(route('investor_withdraw_modal'), false); ?>",
				type: 'get',
				success: function(data) {
					$('#window-withdraw .modal-body').html(data);
				}
			});
		});

	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/investor/finances.blade.php ENDPATH**/ ?>