<?php if($user): ?>
<div class="profile profile-base <?php if($alg == 'center'): ?> profile-center2 <?php endif; ?> <?php if($alg == 'right'): ?> profile-alt <?php endif; ?> <?php if($size == 'big'): ?> profile-lg <?php endif; ?> <?php if($size == 'middle'): ?> profile-md <?php endif; ?> <?php if($size == 'mini'): ?> profile-sm <?php endif; ?> ">
	<div class="profile_pic">
		<div class="avatar <?php if($size == 'big'): ?> avatar-lg <?php endif; ?> <?php if($size == 'middle'): ?> avatar-md <?php endif; ?> <?php if($size == 'mini'): ?> avatar-sm <?php endif; ?> avatar-active">

			<a href="#" role="button" id="dropdownMenuLink<?php echo e($user->id, false); ?>" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="avatar_wrapper notAjax <?php if($user->binar AND $user->binar->activated): ?> avatar_wrapper_blue <?php endif; ?>">
				<?php if($user->getMedia('avatars')->first()): ?>
				<img width="120" height="120" class="avatar_image" src="<?php echo e($user->getMedia('avatars')->first()->getUrl('thumb_big'), false); ?>">
				<?php else: ?>
				<img width="120" height="120" class="avatar_image" src="<?php echo e(asset('theme/img/man.jpeg'), false); ?>">
				<?php endif; ?>
			</a>

			<?php if(!$main): ?>
			<div class="dropdown-menu" aria-labelledby="dropdownMenuLink<?php echo e($user->id, false); ?>">
				<a class="dropdown-item" href="<?php echo e(route('team', ['user' => $user->id]), false); ?>"><?php echo e(__('Show structure'), false); ?></a>
				<?php if($user->binar): ?>
				<?php if($user->binar AND $user->binar->redirect()): ?>
				<a class="dropdown-item" href="<?php echo e(route('remove_redirect', ['binar_id' => $user->binar->id]), false); ?>"><?php echo e(__('Remove redirect'), false); ?></a>
				<?php else: ?>
				<a class="dropdown-item" href="<?php echo e(route('set_redirect', ['binar_id' => $user->binar->id]), false); ?>"><?php echo e(__('Set redirect'), false); ?></a>
				<?php endif; ?>
				<?php endif; ?>
			</div>
			<?php endif; ?>

			<?php if($user->binar AND $user->binar->redirect()): ?>
			<span class="set_redirect">
				<i class="fas fa-share"></i>
			</span>
			<?php endif; ?>

			<span class="avatar_caption qualify <?php if($user->binar AND $user->binar->activated): ?> qualify_blue <?php endif; ?>">
				<?php if($user->binar): ?>
				<?php if($user->binar->type == 1): ?>
				Std
				<?php endif; ?>
				<?php if($user->binar->type == 2): ?>
				Gld
				<?php endif; ?>
				<?php if($user->binar->type == 3): ?>
				VIP
				<?php endif; ?>
				<?php else: ?>
				–
				<?php endif; ?>
			</span>

			<?php if($size == 'big'): ?>
			<canvas height="108" width="108"></canvas>
			<?php endif; ?>

			<?php if($size == 'middle'): ?>
			<canvas height="82" width="82"></canvas>
			<?php endif; ?>

			<?php if($size == 'mini'): ?>
			<canvas height="64" width="64"></canvas>
			<?php endif; ?>

		</div>
	</div>
	<div class="profile_info">


		<div class="dropdown">

			<a class="profile_info__name" href="#" role="button" id="dropdownMenuLink<?php echo e($user->id, false); ?>_2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				<span><?php echo e($user->first_name, false); ?></span>
				<span><?php echo e($user->last_name, false); ?></span>
			</a>

			<?php if(!$main): ?>
			<div class="dropdown-menu" aria-labelledby="dropdownMenuLink<?php echo e($user->id, false); ?>_2">
				<a class="dropdown-item" href="<?php echo e(route('team', ['user' => $user->id]), false); ?>"><?php echo e(__('Show structure'), false); ?></a>
				<?php if($user->binar): ?>
				<?php if($user->binar AND $user->binar->redirect()): ?>
				<a class="dropdown-item" href="<?php echo e(route('remove_redirect', ['binar_id' => $user->binar->id]), false); ?>"><?php echo e(__('Remove redirect'), false); ?></a>
				<?php else: ?>
				<a class="dropdown-item" href="<?php echo e(route('set_redirect', ['binar_id' => $user->binar->id]), false); ?>"><?php echo e(__('Set redirect'), false); ?></a>
				<?php endif; ?>
				<?php endif; ?>
			</div>
			<?php endif; ?>
		</div>



	</div>
</div>
<?php else: ?>
<div class="profile profile-base <?php if($alg == 'center'): ?> profile-center2 <?php endif; ?> <?php if($alg == 'right'): ?> profile-alt <?php endif; ?> <?php if($size == 'big'): ?> profile-lg <?php endif; ?> <?php if($size == 'middle'): ?> profile-md <?php endif; ?> <?php if($size == 'mini'): ?> profile-sm <?php endif; ?> ">
	<div class="profile_pic">
		<div class="avatar <?php if($alg == 'right'): ?> avatar-alt <?php endif; ?> <?php if($size == 'big'): ?> avatar-lg <?php endif; ?> <?php if($size == 'middle'): ?> avatar-md <?php endif; ?> <?php if($size == 'mini'): ?> avatar-sm <?php endif; ?> avatar-inactive avatar-empty">
			<span class="avatar_wrapper ">
				<div class="avatar-lock">
					<i class="fas fa-lock"></i>
				</div>
			</span>

			<?php if($size == 'big'): ?>
			<canvas height="108" width="108"></canvas>
			<?php endif; ?>

			<?php if($size == 'middle'): ?>
			<canvas height="82" width="82"></canvas>
			<?php endif; ?>

			<?php if($size == 'mini'): ?>
			<canvas height="64" width="64"></canvas>
			<?php endif; ?>
		</div>
	</div>
	<div class="profile_info">
		<div class="dropdown">
			<div class="profile_info__name">
				<span></span>
				<span></span>
			</div>
		</div>
	</div>
</div>

<?php endif; ?><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/components/team-person.blade.php ENDPATH**/ ?>