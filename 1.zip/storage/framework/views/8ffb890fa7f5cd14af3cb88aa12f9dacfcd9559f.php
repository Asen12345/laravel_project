<?php $__env->startSection('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Users'), false); ?></h1>

	<!-- <a class="btn btn-danger" href="<?php echo e(route('admin.robots.create'), false); ?>">
		<?php echo e(__('Create robot'), false); ?>

	</a> -->
</div>

<!-- Row -->
<div class="row">
	<!-- DataTable -->
	<div class="col-lg-12">
		<div class="card mb-4">

			<div class="card-header py-3 d-flex flex-row align-items-center justify-content-end">

			</div>
			<!-- </div> -->


			<div class="table-responsive p-3">
				<table class="table align-items-center table-flush table-hover" id="users">
					<thead class="thead-light">
						<tr>
							<th><?php echo e(__('Full name'), false); ?></th>
							<th><?php echo e(__('E-mail'), false); ?></th>
							<th><?php echo e(__('Avatar'), false); ?></th>
							<th><?php echo e(__('Phone'), false); ?></th>
							<th style="display: none2;"><?php echo e(__('Account numbers'), false); ?></th>
							<th><?php echo e(__('Date registration'), false); ?></th>
						</tr>
					</thead>
					<tbody>

						<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>

							<td>
								<a href="<?php echo e(route('admin.users.info', $user->id), false); ?>"><?php echo e($user->first_name, false); ?> <?php echo e($user->last_name, false); ?></a>
							</td>
							<td>
								<?php echo e($user->email, false); ?>

							</td>
							<td>
								<?php if($user->getFirstMediaUrl('avatars', 'thumb')): ?>
								<img class="rounded-circle" width="60" height="60" src="<?php echo e($user->getFirstMediaUrl('avatars', 'thumb'), false); ?>">
								<?php endif; ?>
							</td>
							<td>
								<?php echo e($user->phone, false); ?>

							</td>
							<td style="display: none2;">

								<?php $__empty_2 = true; $__currentLoopData = $user->accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
								<?php if($account->number): ?>
								<div><?php echo e($account->number, false); ?></div>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
								Нет счетов
								<?php endif; ?>

							</td>
							<td>
								<?php if($user->created_at): ?>
								<?php echo e(date('d.m.Y H:i', strtotime($user->created_at)), false); ?>

								<?php else: ?>
								–
								<?php endif; ?>
							</td>

						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<?php endif; ?>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<!--Row-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('theme/vendor/datatables/jquery.dataTables.min.js'), false); ?>"></script>
<script src="<?php echo e(asset('theme/vendor/datatables/dataTables.bootstrap4.min.js'), false); ?>"></script>

<?php if(app()->getLocale() == 'ru'): ?>
<?php ($locale = "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Russian.json"); ?>
<?php else: ?>
<?php ($locale = "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/English.json"); ?>
<?php endif; ?>

<!-- Page level custom scripts -->
<script>
	$(document).ready(function() {

		// Таблица
		$('#users').DataTable({
			"language": {
				"url": "<?php echo e($locale, false); ?>"
			},
			"order": false
		});

	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/admin/users/index.blade.php ENDPATH**/ ?>