<?php $__env->startSection('content'); ?>

<!-- <?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
	<?php echo e(session('status'), false); ?>

</div>
<?php endif; ?> -->


<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Promo materials'), false); ?></h1>
</div>


<div class="toast hide" role="alert" aria-live="assertive" aria-atomic="true" id="toast" data-delay="2000" style="position: absolute; top: 85px; right: 20px; z-index: 10000;">
	<div class="toast-header">
		<svg class="bd-placeholder-img rounded mr-2" width="20" height="20" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img">
			<rect width="100%" height="100%" fill="#007aff"></rect>
		</svg>

		<strong class="mr-auto"><?php echo e(__('Copying'), false); ?></strong>
		<!-- <small>только что</small> -->
		<button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
	</div>
	<div class="toast-body">
		<?php echo e(__('Successfully!'), false); ?>

	</div>
</div>


<div class="row">
	<div class="col-md-6">
		<div class="card mb-4">
			<!-- <div class="card-header">
				<h6 class="m-0 font-weight-bold text-primary pt-3"><?php echo e(__('Promo materials'), false); ?></h6>
			</div> -->

			<div class="card-body">


				<div class="form-group">
					<label for="vk"><?php echo e(__('Partner link'), false); ?></label>

					<div class="input-group is-invalid">
						<input id="ref_link" type="text" class="form-control" value="<?php echo e(auth()->user()->ref(), false); ?>">
						<div class="input-group-append">
							<button class="btn btn-outline-secondary" type="button" onclick="copytext('#ref_link')"><?php echo e(__('Copy'), false); ?></button>
						</div>
					</div>

				</div>


			</div>
		</div>



		<div class="card mb-4">
			<div class="card-header">
				<h6 class="m-0 font-weight-bold text-primary pt-3"><?php echo e(__('Promo materials'), false); ?></h6>
				<!-- <?php echo e(__('Capture pages'), false); ?> -->
			</div>

			<div class="card-body">


				<?php $__empty_1 = true; $__currentLoopData = $promo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<div class="mt-3 d-flex flex-row align-items-center justify-content-between">
					<h5 class=""><?php echo e($p->title, false); ?></h5>
					<?php if($p->getFirstMediaUrl('zips')): ?>
					<a class="btn btn-success" download target="_blank" href="<?php echo e($p->getFirstMediaUrl('zips'), false); ?>"><?php echo e(__('Download'), false); ?></a>
					<?php endif; ?>
				</div>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<p><?php echo e(__('No promo'), false); ?></p>
				<?php endif; ?>




				


		</div>
	</div>

</div>
</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
<script>
	function copytext(el) {
		var $tmp = $("<textarea>");
		$("body").append($tmp);
		$tmp.val($(el).val()).select();
		document.execCommand("copy");
		$tmp.remove();

		$('#toast').toast('show');
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/promo.blade.php ENDPATH**/ ?>