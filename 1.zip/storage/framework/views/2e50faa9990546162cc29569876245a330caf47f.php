<?php $__env->startSection('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Licenses'), false); ?></h1>
	<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#window-buy" id="#modalCenter">
		<?php echo e(__('Buy a license'), false); ?>

	</button>
</div>

<!-- Row -->
<div class="row">
	<!-- DataTable -->
	<div class="col-lg-12">
		<div class="card mb-4">

			<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
				<h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Free licenses'), false); ?></h6>
			</div>

			<div class="table-responsive p-3">
				<table class="table align-items-center table-flush table-hover" id="licenses_one">
					<thead class="thead-light">
						<tr>
							<th><?php echo e(__('Activation key'), false); ?></th>
							<th><?php echo e(__('Date activation'), false); ?></th>
							<th><?php echo e(__('Check number'), false); ?></th>
							<th><?php echo e(__('Check type'), false); ?></th>
							<th></th>
						</tr>
					</thead>
					<tbody>



						<?php $__empty_1 = true; $__currentLoopData = $accounts_one; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><?php echo e($account->active_kod, false); ?></td>
							<td>
								<?php if($account->date_activation AND $account->date_activation != '0000-00-00 00:00:00' AND $account->date_activation != NULL): ?>
								<?php echo e(date('d.m.Y H:i', strtotime($account->date_activation)), false); ?>

								<?php else: ?>
								–
								<?php endif; ?></td>
							<td>
								<?php if($account->number): ?>
								<?php echo e($account->number, false); ?>

								<?php else: ?>
								–
								<?php endif; ?>
							</td>
							<td>
								<?php if($account->activated): ?>
								<?php if($account->real): ?>
								<span class="badge badge-success"><?php echo e(__('Real'), false); ?></span>
								<?php else: ?>
								<?php if($account->real === NULL): ?>
								–
								<?php else: ?>
								<span class="badge badge-danger"><?php echo e(__('Demo'), false); ?></span>
								<?php endif; ?>
								<?php endif; ?>
								<?php else: ?>
								–
								<?php endif; ?>
							</td>
							<td>
								

								<button class="btn btn-success" type="button" data-toggle="modal" data-target="#window-activate<?php echo e($account->id, false); ?>" id="#modalCenter">
									<?php echo e(__('To activate'), false); ?>

								</button>

							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<?php endif; ?>

					</tbody>
				</table>
			</div>
		</div>

		<div class="card mb-4">

			<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
				<h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('My licenses'), false); ?></h6>
			</div>

			<div class="table-responsive p-3">
				<table class="table align-items-center table-flush table-hover" id="licenses_two">
					<thead class="thead-light">
						<tr>
							<th><?php echo e(__('Activation key'), false); ?></th>
							<th><?php echo e(__('Date activation'), false); ?></th>
							<th><?php echo e(__('Check number'), false); ?></th>
							<th><?php echo e(__('Check type'), false); ?></th>
							<th></th>
						</tr>
					</thead>
					<tbody>



						<?php $__empty_1 = true; $__currentLoopData = $accounts_two; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><?php echo e($account->active_kod, false); ?></td>
							<td>
								<?php if($account->date_activation AND $account->date_activation != '0000-00-00 00:00:00' AND $account->date_activation != NULL): ?>
								<?php echo e(date('d.m.Y H:i', strtotime($account->date_activation)), false); ?>

								<?php else: ?>
								–
								<?php endif; ?></td>
							<td>
								<?php if($account->number): ?>
								<?php echo e($account->number, false); ?>

								<?php else: ?>
								<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#window-account-number" num="<?php echo e($account->id, false); ?>" id="#modalCenter">
									<?php echo e(__('To appoint'), false); ?>

								</button>
								<?php endif; ?>
							</td>
							<td>
								<?php if($account->activated): ?>
								<?php if($account->real): ?>
								<span class="badge badge-success"><?php echo e(__('Real'), false); ?></span>
								<?php else: ?>
								<?php if($account->real === NULL): ?>
								–
								<?php else: ?>
								<span class="badge badge-danger"><?php echo e(__('Demo'), false); ?></span>
								<?php endif; ?>
								<?php endif; ?>
								<?php else: ?>
								–
								<?php endif; ?>
							</td>
							<td>
								<?php if($account->number): ?>
								<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#window-detail<?php echo e($account->id, false); ?>" id="#modalCenter">
									<?php echo e(__('Detail'), false); ?>

								</button>
								<?php endif; ?>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<?php endif; ?>

					</tbody>
				</table>
			</div>
		</div>

		<div class="card mb-4">

			<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
				<h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Client licenses'), false); ?></h6>
			</div>

			<div class="table-responsive p-3">
				<table class="table align-items-center table-flush table-hover" id="licenses_three">
					<thead class="thead-light">
						<tr>
							<th><?php echo e(__('Activation key'), false); ?></th>
							<th><?php echo e(__('Date activation'), false); ?></th>
							<th><?php echo e(__('Check number'), false); ?></th>
							<th><?php echo e(__('Check type'), false); ?></th>
							<th></th>
						</tr>
					</thead>
					<tbody>



						<?php $__empty_1 = true; $__currentLoopData = $accounts_three; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><?php echo e($account->active_kod, false); ?></td>
							<td>
								<?php if($account->date_activation AND $account->date_activation != '0000-00-00 00:00:00' AND $account->date_activation != NULL): ?>
								<?php echo e(date('d.m.Y H:i', strtotime($account->date_activation)), false); ?>

								<?php else: ?>
								–
								<?php endif; ?></td>
							<td>
								<?php if($account->number): ?>
								<?php echo e($account->number, false); ?>

								<?php else: ?>
								<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#window-account-number" num="<?php echo e($account->id, false); ?>" id="#modalCenter">
									<?php echo e(__('To appoint'), false); ?>

								</button>
								<?php endif; ?>
							</td>
							<td>
								<?php if($account->activated): ?>
								<?php if($account->real): ?>
								<span class="badge badge-success"><?php echo e(__('Real'), false); ?></span>
								<?php else: ?>
								<?php if($account->real === NULL): ?>
								–
								<?php else: ?>
								<span class="badge badge-danger"><?php echo e(__('Demo'), false); ?></span>
								<?php endif; ?>
								<?php endif; ?>
								<?php else: ?>
								–
								<?php endif; ?>
							</td>
							<td>
								<?php if($account->number): ?>
								<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#window-detail<?php echo e($account->id, false); ?>" id="#modalCenter">
									<?php echo e(__('Detail'), false); ?>

								</button>
								<?php endif; ?>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<?php endif; ?>

					</tbody>
				</table>
			</div>
		</div>

	</div>
</div>
<!--Row-->



<?php $__empty_1 = true; $__currentLoopData = $accounts_one; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<!-- Modal Center -->
<div class="modal fade" id="window-activate<?php echo e($account->id, false); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('Activate license'), false); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">

				<form class="form_activate" num="<?php echo e($account->id, false); ?>">
					<?php echo csrf_field(); ?>

					<input id="license_id<?php echo e($account->id, false); ?>" name="license_id<?php echo e($account->id, false); ?>" value="<?php echo e($account->id, false); ?>" type="hidden">

					<div class="form-group">
						<label for="person"><?php echo e(__('Account number'), false); ?></label>

						<select id="person<?php echo e($account->id, false); ?>" name="person<?php echo e($account->id, false); ?>" class="form-control person_input_error person_select">
							<option value="my"><?php echo e(__('Activate yourself'), false); ?></option>
							<option value="email"><?php echo e(__('Activate user'), false); ?></option>
						</select>

						<span class="invalid-feedback person_error" role="alert">
							<strong></strong>
						</span>
					</div>

					<div class="form-group activate_email">
						<label for="activate_email"><?php echo e(__('Email'), false); ?></label>
						<input id="activate_email<?php echo e($account->id, false); ?>" type="text" class="form-control activate_email_input_error" name="activate_email<?php echo e($account->id, false); ?>">

						<span class="invalid-feedback activate_email_text_error" role="alert">
							<strong></strong>
						</span>
					</div>

					<div class="invalid-feedback alert alert-danger other_text_error" role="alert">
						<strong></strong>
					</div>

				</form>

				<div class="form-group">
					<button class="btn btn-success to-activate-license" num="<?php echo e($account->id, false); ?>">
						<div class="activate_license_loader spinner-border spinner-border-sm float-left text-light mr-2 mt-1" role="status">
							<span class="sr-only">Loading...</span>
						</div>
						<?php echo e(__('Activate'), false); ?>

					</button>
				</div>

			</div>
		</div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<?php endif; ?>


<!-- Назначить номер счета -->
<div class="modal fade" id="window-account-number" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('To appoint account number'), false); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">

				<form class="to_appoint_form">
					<?php echo csrf_field(); ?>

					<input id="account_id" name="id" value="0" type="hidden">

					<div class="form-group">
						<label for="email"><?php echo e(__('Account number'), false); ?></label>

						<input id="account_number" type="text" class="form-control account_number_input_error" name="number" value="">

						<span class="invalid-feedback account_number_error" role="alert">
							<strong></strong>
						</span>

					</div>

				</form>

				<div class="form-group">
					<button class="btn btn-success to-appoint"><?php echo e(__('To appoint'), false); ?></button>
				</div>

			</div>
		</div>
	</div>
</div>

<!-- Купить лицензию -->
<div class="modal fade" id="window-buy" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('Buy a license'), false); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('License price'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php echo e(number_format($license_price, 0, " ", " "), false); ?> $
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('For partner'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php echo e(number_format($for_partner, 0, " ", " "), false); ?> $
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('For pay'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php echo e(number_format($for_pay, 0, " ", " "), false); ?> $
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Баланс счета'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php echo e(number_format(auth()->user()->balance(), 0, " ", " "), false); ?> $
					</div>
				</div>

				<div class="form-group">
					<div class="alert alert-danger invalid-feedback other_text_error mt-4" role="alert">
						<strong></strong>
					</div>
				</div>

				<div class="form-group">
					<button type="submit" class="btn btn-primary to-buy">
						<?php echo e(__('Pay'), false); ?>

					</button>
				</div>


			</div>
		</div>
	</div>
</div>

<?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<!-- Modal Center -->
<div class="modal fade" id="window-detail<?php echo e($account->id, false); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('License details'), false); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Activation key'), false); ?></div>
					<div class="col-md-6 text-right"><?php echo e($account->active_kod, false); ?></div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Robot'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php if($account->project): ?>
						<?php echo e($account->project->name, false); ?>

						<?php else: ?>
						<?php echo e($account->project_id, false); ?>

						<?php endif; ?>
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Robot version'), false); ?></div>
					<div class="col-md-6 text-right"><?php echo e($account->ver, false); ?></div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Date activation'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php if($account->date_activation): ?>
						<?php echo e(date('d.m.Y H:i', strtotime($account->date_activation)), false); ?>

						<?php else: ?>
						–
						<?php endif; ?>
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Date end of license'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php if($account->date_expiration): ?>
						<?php echo e(date('d.m.Y H:i', strtotime($account->date_expiration)), false); ?>

						<?php else: ?>
						–
						<?php endif; ?>
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Check number'), false); ?></div>
					<div class="col-md-6 text-right"><?php echo e($account->number, false); ?></div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Shoulder'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php if($account->leverage): ?>
						1:<?php echo e($account->leverage, false); ?>

						<?php else: ?>
						–
						<?php endif; ?>
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-6"><?php echo e(__('Check type'), false); ?></div>
					<div class="col-md-6 text-right">
						<?php if($account->activated): ?>
						<?php if($account->real): ?>
						<span class="badge badge-success"><?php echo e(__('Real'), false); ?></span>
						<?php else: ?>
						<?php if($account->real === NULL): ?>
						–
						<?php else: ?>
						<span class="badge badge-danger"><?php echo e(__('Demo'), false); ?></span>
						<?php endif; ?>
						<?php endif; ?>
						<?php else: ?>
						–
						<?php endif; ?>
					</div>
				</div>

			</div>
		</div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<!-- 33028645 -->


<?php $__env->startSection('scripts'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('theme/vendor/datatables/jquery.dataTables.min.js'), false); ?>"></script>
<script src="<?php echo e(asset('theme/vendor/datatables/dataTables.bootstrap4.min.js'), false); ?>"></script>

<?php if(app()->getLocale() == 'ru'): ?>
<?php ($locale = "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Russian.json"); ?>
<?php else: ?>
<?php ($locale = "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/English.json"); ?>
<?php endif; ?>

<!-- Page level custom scripts -->
<script>
	$(document).ready(function() {
		$('#licenses_one').DataTable({
			"language": {
				"url": "<?php echo e($locale, false); ?>"
			}
		});

		$('#licenses_two').DataTable({
			"language": {
				"url": "<?php echo e($locale, false); ?>"
			}
		});

		$('#licenses_three').DataTable({
			"language": {
				"url": "<?php echo e($locale, false); ?>"
			}
		});

		$('.activate_license_loader').hide();

		// Функция показать ошибку
		function error_field(field, error = true, text) {
			if (error) {
				$('.' + field + '_text_error strong').html(text);
				$('.' + field + '_text_error').show();
				$('.' + field + '_input_error').addClass('is-invalid');
			} else {
				$('.' + field + '_text_error strong').html('');
				$('.' + field + '_text_error').hide();
				$('.' + field + '_input_error').removeClass('is-invalid');
			}
		}

		error_field('other', false);

		$('.activate_email').hide();

		$('select.person_select').on('change', function() {
			if ($(this).val() == 'email') {
				$('.activate_email').show();
			} else {
				$('.activate_email').hide();
			}
		});

		$('#window-account-number').on('show.bs.modal', function(e) {
			$('#account_id').val($(e.relatedTarget).attr('num'));
		});

		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		$('.to-activate-license').on('click', function() {
			var num = $(this).attr('num');
			$('button[num=' + num + ']' + ' .activate_license_loader').show();
			$.ajax({
				url: "<?php echo e(route('to_activate_license'), false); ?>",
				type: 'post',
				data: {
					'id': $('#license_id' + num).val(),
					'person': $('#person' + num).val(),
					'email': $('#activate_email' + num).val()
				},
				success: function(data) {
					console.log(data);

					error_field('other', false);
					error_field('activate_email', false);

					$('.activate_license_loader').hide();

					if (data.error) {
						if (data.error.other) {
							error_field('other', true, data.error.other[0]);
						}
						if (data.error.email) {
							error_field('activate_email', true, data.error.email[0]);
						}
					} else {
						location.reload();
					}

				},
				error: function(error) {
					console.log(error);
				}
			});
		});


		$(document).on('submit', 'form.to_appoint_form', function(event) {
			event.preventDefault();
			console.log('asdadsasd');
			to_appoint();
		});



		$('.to-appoint').on('click', function() {
			to_appoint();
		});


		function to_appoint() {
			$.ajax({
				url: "<?php echo e(route('to_appoint'), false); ?>",
				type: 'post',
				data: {
					'id': $('#account_id').val(),
					'number': $('#account_number').val()
				},
				success: function(data) {
					console.log(data);

					if (data.error) {
						$('.account_number_error strong').html(data.error[0]);
						$('.account_number_error').show();
						$('.account_number_input_error').addClass('is-invalid');
					} else {
						location.reload();
					}

				},
				error: function(error) {
					console.log(error);
				}
			});
		}


		// Купить лицензию
		$('.to-buy').on('click', function() {
			$.ajax({
				url: "<?php echo e(route('license_buy'), false); ?>",
				type: 'post',
				success: function(data) {

					error_field('other', false);

					if (data.errors) {
						if (data.errors.other) {
							error_field('other', true, data.errors.other[0]);
						}
					} else {
						location.reload();
					}

				}
			});
		});


	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/licenses.blade.php ENDPATH**/ ?>