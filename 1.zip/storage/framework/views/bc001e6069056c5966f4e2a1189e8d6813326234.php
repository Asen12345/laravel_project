<?php $__env->startSection('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Partners'), false); ?></h1>
</div>

<!-- Row -->
<div class="row">
	<!-- DataTable -->
	<div class="col-lg-12">
		<div class="card mb-4">
			<!-- <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"> -->
			<!-- <h6 class="m-0 font-weight-bold text-primary"></h6> -->
			<!-- </div> -->
			<div class="table-responsive p-3">
				<table class="table align-items-center table-flush table-hover" id="partners">
					<thead class="thead-light">
						<tr>
							<th><?php echo e(__('Registration date'), false); ?></th>
							<th><?php echo e(__('Fullname'), false); ?></th>
							<th><?php echo e(__('E-mail'), false); ?></th>
							<th><?php echo e(__('Status'), false); ?></th>
						</tr>
					</thead>
					<!-- <tfoot>
						<tr>
							<th><?php echo e(__('Registration date'), false); ?></th>
							<th><?php echo e(__('Fullname'), false); ?></th>
							<th><?php echo e(__('E-mail'), false); ?></th>
							<th><?php echo e(__('Status'), false); ?></th>
						</tr>
					</tfoot> -->
					<tbody>

						<?php $__empty_1 = true; $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><?php echo e(date('d.m.Y H:i', strtotime($partner->created_at)), false); ?></td>
							<td><?php echo e($partner->first_name, false); ?> <?php echo e($partner->last_name, false); ?></td>
							<td>

								<a href="#" data-toggle="modal" data-target="#window-partner<?php echo e($partner->id, false); ?>" id="#modalCenter"><?php echo e($partner->email, false); ?></a>

							</td>
							<td><?php echo $partner->status(); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<?php endif; ?>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<!--Row-->


<?php $__empty_1 = true; $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<!-- Modal Center -->
<div class="modal fade" id="window-partner<?php echo e($partner->id, false); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e($partner->first_name, false); ?> <?php echo e($partner->last_name, false); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">

				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('Registration date'), false); ?></div>
					<div class="col-md-8 text-right"><?php echo e(date('d.m.Y H:i', strtotime($partner->created_at)), false); ?></div>
				</div>

				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('Tariff'), false); ?></div>
					<div class="col-md-8 text-right">
						<b>
							<?php if($partner->binar): ?>
							<?php if($partner->binar->type == 1): ?>
							Standard
							<?php endif; ?>
							<?php if($partner->binar->type == 2): ?>
							Gold
							<?php endif; ?>
							<?php if($partner->binar->type == 3): ?>
							VIP
							<?php endif; ?>

							<?php else: ?>
							–
							<?php endif; ?>
						</b>
					</div>
				</div>

				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('Status'), false); ?></div>
					<div class="col-md-8 text-right"><?php echo $partner->status(); ?></div>
				</div>

				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('E-mail'), false); ?></div>
					<div class="col-md-8 text-right"><a href="mailto:<?php echo e($partner->email, false); ?>"><?php echo e($partner->email, false); ?></a></div>
				</div>

				<?php if($partner->phone): ?>
				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('Phone'), false); ?></div>
					<div class="col-md-8 text-right"><a href"tel:+<?php echo e($partner->phone, false); ?>"><?php echo e($partner->phoneNumber(), false); ?></a></div>
				</div>
				<?php endif; ?>

				<div class="my-3 row">
					<div class="col-md-4"><?php echo e(__('Contacts'), false); ?></div>
					<div class="col-md-8 text-right fs-medium">
						<?php if($partner->telegram): ?>
						<a target="_blank" href="https://t.me/<?php echo e($partner->telegram, false); ?>"><i data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Telegram'), false); ?>" class="fab fa-telegram-plane ml-2"></i></a>
						<?php endif; ?>

						<?php if($partner->whatsapp): ?>
						<a target="_blank" href="https://wa.me/<?php echo e($partner->whatsapp, false); ?>"><i data-toggle="tooltip" data-placement="top" title="<?php echo e(__('WhatsApp'), false); ?>" class="fab fa-whatsapp ml-2"></i></a>
						<?php endif; ?>

						<?php if($partner->viber): ?>
						<a target="_blank" href="viber://chat?number=<?php echo e($partner->viber, false); ?>"><i data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Viber'), false); ?>" class="fab fa-viber ml-2"></i></a>
						<?php endif; ?>

						<?php if($partner->instagram): ?>
						<a target="_blank" href="https://www.instagram.com/<?php echo e($partner->instagram, false); ?>"><i data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Instagram'), false); ?>" class="fab fa-instagram ml-2"></i></a>
						<?php endif; ?>

						<?php if($partner->fb): ?>
						<a target="_blank" href="https://www.facebook.com/<?php echo e($partner->fb, false); ?>"><i data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Facebook'), false); ?>" class="fab fa-facebook-f ml-2"></i></a>
						<?php endif; ?>

						<?php if($partner->vk): ?>
						<a target="_blank" href="https://vk.com/<?php echo e($partner->vk, false); ?>"><i data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Vkontakte'), false); ?>" class="fab fa-vk ml-2"></i></a>
						<?php endif; ?>
					</div>
				</div>

			</div>
		</div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<?php endif; ?>

<style>
	.fs-medium {
		font-size: 20px;
	}
</style>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('theme/vendor/datatables/jquery.dataTables.min.js'), false); ?>"></script>
<script src="<?php echo e(asset('theme/vendor/datatables/dataTables.bootstrap4.min.js'), false); ?>"></script>

<?php if(app()->getLocale() == 'ru'): ?>
<?php ($locale = "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Russian.json"); ?>
<?php else: ?>
<?php ($locale = "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/English.json"); ?>
<?php endif; ?>

<!-- Page level custom scripts -->
<script>
	$(document).ready(function() {
		$('#partners').DataTable({
			"language": {
				"url": "<?php echo e($locale, false); ?>"
			}
		});
	});

	$(function() {
		$('[data-toggle="tooltip"]').tooltip()
	})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/partners.blade.php ENDPATH**/ ?>