<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale()), false); ?>">

<head>
	<meta charset="utf-8">

	<!-- CSRF Token -->
	

	<base href="<?php echo e(url(''), false); ?>">

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<!-- <link href="<?php echo e(asset('theme/img/logo/logo.png'), false); ?>" rel="icon"> -->
	<title><?php echo e(config('app.name', 'Laravel'), false); ?></title>
	<link rel="shortcut icon" href="<?php echo e(asset('theme/img/favicon.ico'), false); ?>" type="image/x-icon">
	<link href="<?php echo e(asset('theme/vendor/fontawesome-free/css/all.min.css'), false); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('theme/vendor/bootstrap/css/bootstrap.min.css'), false); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('theme/css/ruang-admin.css'), false); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('theme/css/flag-icon.min.css'), false); ?>" rel="stylesheet">


	<link href="<?php echo e(asset('theme/vendor/datatables/dataTables.bootstrap4.min.css'), false); ?>" rel="stylesheet">

</head>

<body id="page-top">
	<div id="wrapper">
		<!-- Sidebar -->
		<ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
			<a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(url('/'), false); ?>">
				<div class="sidebar-brand-icon">
					<!-- <img src="<?php echo e(asset('theme/img/logo/logo2.png'), false); ?>"> -->
					<?php echo e(config('app.name', 'Laravel'), false); ?>

				</div>
				<div class="sidebar-brand-text mx-3">

					<!-- <a class="navbar-brand" href="<?php echo e(url('/'), false); ?>">
						<?php echo e(config('app.name', 'Laravel'), false); ?>

					</a> -->

				</div>
			</a>
			<hr class="sidebar-divider my-0">
			<li class="nav-item active">
				<a class="nav-link" href="<?php echo e(route('dashboard'), false); ?>">
					<i class="fas fa-fw fa-tachometer-alt"></i>
					<span><?php echo e(__('Dashboard'), false); ?></span></a>
			</li>

			<!--  -->


			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('promo'), false); ?>">
					<i class="fas fa-ad fa-id-badge2"></i>
					<span><?php echo e(__('Promo'), false); ?></span></a>
			</li>


			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('finances'), false); ?>">
					<i class="fas fa-wallet fa-id-badge"></i>
					<span><?php echo e(__('My finances'), false); ?></span></a>
			</li>

			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('curator'), false); ?>">
					<i class="fas fa-fw fa-user-tie"></i>
					<span><?php echo e(__('Curator'), false); ?></span></a>
			</li>

			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('partners'), false); ?>">
					<i class="fas fa-fw fa-user-friends"></i>
					<span><?php echo e(__('Partners'), false); ?></span></a>
			</li>

			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('team'), false); ?>">
					<i class="fas fa-sitemap fa-id-badge"></i>
					<span><?php echo e(__('Team scheme'), false); ?></span></a>
			</li>

			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('licenses'), false); ?>">
					<i class="fas fa-fw fa-id-badge"></i>
					<span><?php echo e(__('Licenses'), false); ?></span></a>
			</li>

			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('robots'), false); ?>">
					<i class="fas fa-robot fa-id-badge"></i>
					<span><?php echo e(__('Robots'), false); ?></span></a>
			</li>

			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('news'), false); ?>">
					<i class="fas fa-list fa-id-badge"></i>
					<span><?php echo e(__('News'), false); ?></span></a>
			</li>


			<?php if (\Illuminate\Support\Facades\Blade::check('admininvestor')): ?>
			<hr class="sidebar-divider">
			<div class="sidebar-heading">
				<?php echo e(__('Investor'), false); ?>

			</div>

			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('investor'), false); ?>">
					<i class="fas fa-search-dollar fa-id-badge"></i>
					<span><?php echo e(__('Investor finance'), false); ?></span></a>
			</li>

			<?php endif; ?>

			<?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
			<hr class="sidebar-divider">
			<div class="sidebar-heading">
				<?php echo e(__('Administration'), false); ?>

			</div>

			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('admin.dashboard'), false); ?>">
					<i class="fas fa-fw fa-tachometer-alt"></i>
					<span><?php echo e(__('Dashboard'), false); ?></span></a>
			</li>

			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('admin.news.index'), false); ?>">
					<i class="fas fa-list fa-id-badge"></i>
					<span><?php echo e(__('News'), false); ?></span></a>
			</li>

			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('admin.robots.index'), false); ?>">
					<i class="fas fa-robot fa-id-badge"></i>
					<span><?php echo e(__('Robots'), false); ?></span></a>
			</li>

			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('admin.users'), false); ?>">
					<i class="fas fa-users fa-id-badge"></i>
					<span><?php echo e(__('Users'), false); ?></span></a>
			</li>

			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('admin.payments'), false); ?>">
					<i class="fas fa-money-check-alt fa-id-badge"></i>
					<span><?php echo e(__('Payments'), false); ?></span></a>
			</li>

			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('admin.licenses'), false); ?>">
					<i class="fas fa-fw fa-id-badge"></i>
					<span><?php echo e(__('Licenses'), false); ?></span></a>
			</li>

			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('admin.promo.index'), false); ?>">
					<i class="fas fa-ad fa-id-badge2"></i>
					<span><?php echo e(__('Promo'), false); ?></span></a>
			</li>

			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('admin.settings.index'), false); ?>">
					<i class="fas fa-tools fa-id-badge"></i>
					<span><?php echo e(__('Settings'), false); ?></span></a>
			</li>

			<?php endif; ?>

			<!-- 
			<li class="nav-item">
				<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseBootstrap" aria-expanded="true" aria-controls="collapseBootstrap">
					<i class="far fa-fw fa-window-maximize"></i>
					<span>Bootstrap UI</span>
				</a>
				<div id="collapseBootstrap" class="collapse" aria-labelledby="headingBootstrap" data-parent="#accordionSidebar">
					<div class="bg-white py-2 collapse-inner rounded">
						<h6 class="collapse-header">Bootstrap UI</h6>
						<a class="collapse-item" href="alerts.html">Alerts</a>
						<a class="collapse-item" href="buttons.html">Buttons</a>
						<a class="collapse-item" href="dropdowns.html">Dropdowns</a>
						<a class="collapse-item" href="modals.html">Modals</a>
						<a class="collapse-item" href="popovers.html">Popovers</a>
						<a class="collapse-item" href="progress-bar.html">Progress Bars</a>
					</div>
				</div>
			</li>
			<li class="nav-item">
				<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseForm" aria-expanded="true" aria-controls="collapseForm">
					<i class="fab fa-fw fa-wpforms"></i>
					<span>Forms</span>
				</a>
				<div id="collapseForm" class="collapse" aria-labelledby="headingForm" data-parent="#accordionSidebar">
					<div class="bg-white py-2 collapse-inner rounded">
						<h6 class="collapse-header">Forms</h6>
						<a class="collapse-item" href="form_basics.html">Form Basics</a>
						<a class="collapse-item" href="form_advanceds.html">Form Advanceds</a>
					</div>
				</div>
			</li>
			<li class="nav-item">
				<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTable" aria-expanded="true" aria-controls="collapseTable">
					<i class="fas fa-fw fa-table"></i>
					<span>Tables</span>
				</a>
				<div id="collapseTable" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
					<div class="bg-white py-2 collapse-inner rounded">
						<h6 class="collapse-header">Tables</h6>
						<a class="collapse-item" href="simple-tables.html">Simple Tables</a>
						<a class="collapse-item" href="datatables.html">DataTables</a>
					</div>
				</div>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="ui-colors.html">
					<i class="fas fa-fw fa-palette"></i>
					<span>UI Colors</span>
				</a>
			</li>
			<hr class="sidebar-divider">
			<div class="sidebar-heading">
				Examples
			</div>
			<li class="nav-item">
				<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePage" aria-expanded="true" aria-controls="collapsePage">
					<i class="fas fa-fw fa-columns"></i>
					<span>Pages</span>
				</a>
				<div id="collapsePage" class="collapse" aria-labelledby="headingPage" data-parent="#accordionSidebar">
					<div class="bg-white py-2 collapse-inner rounded">
						<h6 class="collapse-header">Example Pages</h6>
						<a class="collapse-item" href="login.html">Login</a>
						<a class="collapse-item" href="register.html">Register</a>
						<a class="collapse-item" href="404.html">404 Page</a>
						<a class="collapse-item" href="blank.html">Blank Page</a>
					</div>
				</div>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="charts.html">
					<i class="fas fa-fw fa-chart-area"></i>
					<span>Charts</span>
				</a>
			</li> -->
			<hr class="sidebar-divider">
			<div class="version" id="version-ruangadmin"></div>
		</ul>
		<!-- Sidebar -->
		<div id="content-wrapper" class="d-flex flex-column">
			<div id="content">
				<!-- TopBar -->
				<nav class="navbar navbar-expand navbar-light bg-navbar topbar mb-4 static-top">
					<button id="sidebarToggleTop" class="btn btn-link rounded-circle mr-3">
						<i class="fa fa-bars"></i>
					</button>
					<ul class="navbar-nav ml-auto">


						<li class="nav-item dropdown mx-3">
							<a class="nav-item nav-link dropdown-toggle mr-md-2" href="#" id="bd-versions" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<?php if(App::getLocale() == 'en'): ?> <span class="flag-icon flag-icon-gb"></span> <?php endif; ?>
								<?php if(App::getLocale() == 'ru'): ?> <span class="flag-icon flag-icon-ru"></span> <?php endif; ?>
							</a>
							<div class="dropdown-menu dropdown-menu-md-right" aria-labelledby="bd-versions">

								<a class="dropdown-item <?php if(App::getLocale() == 'en'): ?> nav-link-child-active <?php endif; ?>" href="<?php echo e(route('locale', ['locale' => 'en']), false); ?>"><span class="flag-icon flag-icon-gb mr-2"></span> EN</a>
								<a class="dropdown-item <?php if(App::getLocale() == 'ru'): ?> nav-link-child-active <?php endif; ?>" href="<?php echo e(route('locale', ['locale' => 'ru']), false); ?>"><span class="flag-icon flag-icon-ru mr-2"></span> RU</a>

								<!-- <div class="dropdown-divider"></div> -->

							</div>
						</li>



						<!-- <li class="nav-item dropdown no-arrow mx-1">
							<a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<i class="fas fa-tasks fa-fw"></i>
								<span class="badge badge-success badge-counter">3</span>
							</a>
							<div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="messagesDropdown">
								<h6 class="dropdown-header">
									Task
								</h6>
								<a class="dropdown-item align-items-center" href="#">
									<div class="mb-3">
										<div class="small text-gray-500">Design Button
											<div class="small float-right"><b>50%</b></div>
										</div>
										<div class="progress" style="height: 12px;">
											<div class="progress-bar bg-success" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
										</div>
									</div>
								</a>
								<a class="dropdown-item align-items-center" href="#">
									<div class="mb-3">
										<div class="small text-gray-500">Make Beautiful Transitions
											<div class="small float-right"><b>30%</b></div>
										</div>
										<div class="progress" style="height: 12px;">
											<div class="progress-bar bg-warning" role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
										</div>
									</div>
								</a>
								<a class="dropdown-item align-items-center" href="#">
									<div class="mb-3">
										<div class="small text-gray-500">Create Pie Chart
											<div class="small float-right"><b>75%</b></div>
										</div>
										<div class="progress" style="height: 12px;">
											<div class="progress-bar bg-danger" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
										</div>
									</div>
								</a>
								<a class="dropdown-item text-center small text-gray-500" href="#">View All Taks</a>
							</div>
						</li> -->

						<!-- <div class="topbar-divider d-none d-sm-block"></div> -->


						<?php if(auth()->guard()->check()): ?>
						<?php if(Auth::user()->getMedia('avatars')->first()): ?>
						<?php ($avatar = Auth::user()->getMedia('avatars')->first()->getUrl('thumb')); ?>
						<?php else: ?>
						<?php ($avatar = asset('theme/img/boy.png')); ?>
						<?php endif; ?>

						<li class="nav-item dropdown no-arrow">
							<a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<img class="img-profile rounded-circle" src="<?php echo e($avatar, false); ?>" style="max-width: 60px">
								<span class="ml-2 d-none d-lg-inline text-white small"><?php echo e(Auth::user()->name, false); ?></span>
							</a>
							<div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
								<a class="dropdown-item" href="<?php echo e(route('profile'), false); ?>">
									<i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
									<?php echo e(__('Profile'), false); ?>

								</a>
								<!-- <a class="dropdown-item" href="#">
									<i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
									Settings
								</a>
								<a class="dropdown-item" href="#">
									<i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
									Activity Log
								</a> -->


								<!-- <a class="dropdown-item" href="<?php echo e(route('curator'), false); ?>">
									<i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
									<?php echo e(__('Curator'), false); ?>

								</a> -->

								<!-- <a class="dropdown-item" href="<?php echo e(route('partners'), false); ?>">
									<i class="fas fa-users fa-sm fa-fw mr-2 text-gray-400"></i>
									<?php echo e(__('Partners'), false); ?>

								</a> -->

								<!-- <a class="dropdown-item" href="<?php echo e(route('licenses'), false); ?>">
									<i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
									<?php echo e(__('Licenses'), false); ?>

								</a> -->







								<div class="dropdown-divider"></div>

								<a class="dropdown-item" href="<?php echo e(route('logout'), false); ?>" onclick="event.preventDefault();
																	document.getElementById('logout-form').submit();">
									<?php echo e(__('Logout'), false); ?>

								</a>

								<form id="logout-form" action="<?php echo e(route('logout'), false); ?>" method="POST" class="d-none">
									<?php echo csrf_field(); ?>
								</form>




							</div>
						</li>
						<?php endif; ?>

					</ul>
				</nav>
				<!-- Topbar -->



				<!--
				<?php if(auth()->guard()->guest()): ?>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo e(route('login'), false); ?>"><?php echo e(__('Login'), false); ?></a>
				</li>

				<?php if(Route::has('register')): ?>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo e(route('register'), false); ?>"><?php echo e(__('Register'), false); ?></a>
				</li>
				<?php endif; ?>

				<?php else: ?>
				<li class="nav-item dropdown">
					<a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
						<?php echo e(Auth::user()->name, false); ?>

					</a>

					<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
						<a class="dropdown-item" href="<?php echo e(route('logout'), false); ?>" onclick="event.preventDefault();
																	document.getElementById('logout-form').submit();">
							<?php echo e(__('Logout'), false); ?>

						</a>

						<form id="logout-form" action="<?php echo e(route('logout'), false); ?>" method="POST" class="d-none">
							<?php echo csrf_field(); ?>
						</form>
					</div>
				</li>
				<?php endif; ?>
-->




				<!-- Container Fluid-->
				<div class="container-fluid" id="container-wrapper">
					<?php echo $__env->yieldContent('content'); ?>
				</div>
				<!---Container Fluid-->
			</div>
			<!-- Footer -->
			<footer class="sticky-footer bg-white">
				<div class="container my-auto">
					<div class="copyright text-center my-auto">
						<span>copyright &copy; <script>
								document.write(new Date().getFullYear());
							</script> - <?php echo e(config('app.name', 'Laravel'), false); ?>

						</span>
					</div>
				</div>
			</footer>
			<!-- Footer -->
		</div>
	</div>

	<!-- Scroll to top -->
	<a class="scroll-to-top rounded" href="#page-top">
		<i class="fas fa-angle-up"></i>
	</a>

	<script src="<?php echo e(asset('theme/vendor/jquery/jquery.min.js'), false); ?>"></script>
	<script src="<?php echo e(asset('theme/vendor/bootstrap/js/bootstrap.bundle.min.js'), false); ?>"></script>
	<script src="<?php echo e(asset('theme/vendor/jquery-easing/jquery.easing.min.js'), false); ?>"></script>
	<script src="<?php echo e(asset('theme/js/ruang-admin.min.js'), false); ?>"></script>
	<script src="<?php echo e(asset('theme/js/custom.js'), false); ?>"></script>
	<script src="<?php echo e(asset('theme/vendor/chart.js/Chart.min.js'), false); ?>"></script>
	<script src="<?php echo e(asset('theme/js/demo/chart-area-demo.js'), false); ?>"></script>


	<script src="https://kit.fontawesome.com/fff3308d50.js" crossorigin="anonymous"></script>

	<?php echo $__env->yieldContent('scripts'); ?>

</body>

</html><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/layouts/panel.blade.php ENDPATH**/ ?>