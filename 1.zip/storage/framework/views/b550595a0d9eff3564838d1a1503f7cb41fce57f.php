<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale()), false); ?>">

<head>
	<meta charset="utf-8">

	<!-- CSRF Token -->
	

	<base href="<?php echo e(url(''), false); ?>">

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<!-- <link href="<?php echo e(asset('theme/img/logo/logo.png'), false); ?>" rel="icon"> -->
	<title><?php echo e(config('app.name', 'Laravel'), false); ?></title>
	<link rel="shortcut icon" href="<?php echo e(asset('theme/img/favicon.ico'), false); ?>" type="image/x-icon">
	<link href="<?php echo e(asset('theme/vendor/fontawesome-free/css/all.min.css'), false); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('theme/vendor/bootstrap/css/bootstrap.min.css'), false); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('theme/css/ruang-admin.css'), false); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('theme/css/flag-icon.min.css'), false); ?>" rel="stylesheet">

</head>

<body class="bg-gradient-login">

	<div class="d-flex p-2 bd-highlight justify-content-center">
		<ul class="navbar-nav ml-auto2">
			<li class="nav-item dropdown mx-3">
				<a class="nav-link dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					<?php if(App::getLocale() == 'en'): ?> <span class="flag-icon flag-icon-gb"></span> <?php endif; ?>
					<?php if(App::getLocale() == 'ru'): ?> <span class="flag-icon flag-icon-ru"></span> <?php endif; ?>
				</a>
				<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
					<a class="px-3 nav-link nav-link-child <?php if(App::getLocale() == 'en'): ?> nav-link-child-active <?php endif; ?>" href="<?php echo e(route('locale', ['locale' => 'en']), false); ?>"><span class="flag-icon flag-icon-gb mr-2"></span> EN</a>
					<a class="px-3 nav-link nav-link-child <?php if(App::getLocale() == 'ru'): ?> nav-link-child-active <?php endif; ?>" href="<?php echo e(route('locale', ['locale' => 'ru']), false); ?>"><span class="flag-icon flag-icon-ru mr-2"></span> RU</a>
				</div>
			</li>
		</ul>
	</div>

	<?php echo $__env->yieldContent('content'); ?>

	<script src="<?php echo e(asset('theme/vendor/jquery/jquery.min.js'), false); ?>"></script>
	<script src="<?php echo e(asset('theme/vendor/bootstrap/js/bootstrap.bundle.min.js'), false); ?>"></script>
	<script src="<?php echo e(asset('theme/vendor/jquery-easing/jquery.easing.min.js'), false); ?>"></script>
	<script src="<?php echo e(asset('theme/js/ruang-admin.min.js'), false); ?>"></script>
	<script src="<?php echo e(asset('theme/vendor/chart.js/Chart.min.js'), false); ?>"></script>
	<script src="<?php echo e(asset('theme/js/demo/chart-area-demo.js'), false); ?>"></script>
</body>

</html><?php /**PATH /var/www/www-root/data/www/office.magnumsk.com/resources/views/layouts/blank.blade.php ENDPATH**/ ?>